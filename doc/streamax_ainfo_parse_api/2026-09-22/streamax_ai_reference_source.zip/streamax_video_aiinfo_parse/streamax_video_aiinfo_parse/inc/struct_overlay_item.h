#pragma once

#include <memory>
#include <vector>
#include <string.h>
#include "rmai_info_parse_struct_protocol.h"

/** 单个算法组的 Struct 叠加项（共享 buffer 快照） */
struct StructOverlayGroupItem
{
    std::shared_ptr<std::vector<uint8_t> > buffer;
    RMAI_AlgGroupHeader group;
    uint64_t pts;
    int frameIndex;

    StructOverlayGroupItem()
        : buffer()
        , group()
        , pts(0)
        , frameIndex(0)
    {
        memset(&group, 0, sizeof(group));
    }
};
