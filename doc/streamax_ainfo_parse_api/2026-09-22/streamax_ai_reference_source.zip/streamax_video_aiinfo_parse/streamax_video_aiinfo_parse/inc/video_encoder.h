#pragma once

#if defined(USE_OPENCV)
#include <opencv2/opencv.hpp>
#include <string>

extern "C"
{
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/imgutils.h>
#include <libavutil/dict.h>
#include <libavutil/frame.h>
#include <libswscale/swscale.h>
}

/**
 * @brief 视频编码器类
 * 使用 FFmpeg 将 OpenCV Mat 编码为 MP4 文件
 */
class CVideoEncoder
{
public:
    CVideoEncoder();
    ~CVideoEncoder();

    /**
     * @brief 初始化编码器
     * @param outputPath 输出文件路径
     * @param width 视频宽度
     * @param height 视频高度
     * @param fps 帧率
     * @param codecId 编码器ID（默认 H264）
     * @return 0-成功，-1-失败
     */
    int InitEncoder(const std::string &outputPath, int width, int height, 
                    int fps = 25, AVCodecID codecId = AV_CODEC_ID_H264);

    /**
     * @brief 编码一帧
     * @param mat OpenCV Mat 图像（BGR 格式）
     * @return 0-成功，-1-失败
     */
    int EncodeFrame(const cv::Mat &mat);

    /**
     * @brief 完成编码并关闭文件
     * @return 0-成功，-1-失败
     */
    int Finish();

private:
    AVFormatContext *m_formatCtx;
    AVCodecContext *m_codecCtx;
    AVStream *m_videoStream;
    AVFrame *m_frame;
    AVPacket *m_packet;
    SwsContext *m_swsCtx;
    int m_width;
    int m_height;
    int m_fps;
    int m_frameIndex;
    bool m_initialized;
};

#endif  // USE_OPENCV

