#pragma once

#include <string>
#include <vector>
#include <stdint.h>
#include "struct_overlay_item.h"

/**
 * @brief Struct 叠加管理器
 * 管理算法组叠加项，按 PTS 匹配
 */
class COverlayManager
{
public:
    COverlayManager();
    ~COverlayManager();

    /** 添加单个算法组叠加项 */
    void AddGroup(const StructOverlayGroupItem& item);

    /** 批量添加 */
    void AddGroups(const std::vector<StructOverlayGroupItem>& items);

    /** 按 PTS 查找容差范围内、含可绘制内容的所有叠加项 */
    void FindOverlaysByPts(uint64_t pts,
                           uint64_t tolerance,
                           std::vector<StructOverlayGroupItem>& matched) const;

    /** 移除 PTS 小于 threshold 的项 */
    void RemoveBeforePts(uint64_t threshold);

    const std::vector<StructOverlayGroupItem>& GetAllOverlays() const { return m_overlays; }

    void Clear();

private:
    std::vector<StructOverlayGroupItem> m_overlays;
};
