#pragma once

#include <stdint.h>

extern "C"
{
#include <libavcodec/avcodec.h>
#include <libavutil/imgutils.h>
#include <libswscale/swscale.h>
}

#if defined(USE_OPENCV)
#include <opencv2/opencv.hpp>
#endif

/**
 * @brief 视频解码器类
 * 使用 FFmpeg 解码 H264/H265 视频帧
 */
class CVideoDecoder
{
public:
    CVideoDecoder();
    ~CVideoDecoder();

    /**
     * @brief 初始化解码器
     * @param codecId 编解码器ID（AV_CODEC_ID_H264 或 AV_CODEC_ID_H265）
     * @param width 视频宽度（可选，如果已知）
     * @param height 视频高度（可选，如果已知）
     * @return 0-成功，-1-失败
     */
    int InitDecoder(AVCodecID codecId = AV_CODEC_ID_H264, int width = 0, int height = 0);

    /**
     * @brief 反初始化解码器
     */
    void UnInitDecoder();

    /**
     * @brief 解码一帧视频
     * @param frameData 视频帧数据
     * @param frameLen 数据长度
     * @param avFrame 输出的 AVFrame（可选）
     * @return 1-解码成功，0-需要更多数据，-1-失败
     */
    int DecodeFrame(const uint8_t *frameData, int frameLen, AVFrame **avFrame = NULL);

#if defined(USE_OPENCV)
    /**
     * @brief 将 AVFrame 转换为 OpenCV Mat
     * @param avFrame AVFrame 指针
     * @param mat 输出的 OpenCV Mat
     * @return 0-成功，-1-失败
     */
    int AVFrameToMat(AVFrame *avFrame, cv::Mat &mat);
#endif

    /**
     * @brief 获取视频宽度
     */
    int GetWidth() const { return m_width; }

    /**
     * @brief 获取视频高度
     */
    int GetHeight() const { return m_height; }

private:
    int decode(AVCodecContext *decCtx, AVFrame *frame, AVPacket *pkt);

private:
    const AVCodec *m_codec;
    AVCodecContext *m_codecCtx;
    AVFrame *m_frame;
    AVPacket *m_packet;
    int m_width;
    int m_height;
    AVCodecID m_codecId;
};

