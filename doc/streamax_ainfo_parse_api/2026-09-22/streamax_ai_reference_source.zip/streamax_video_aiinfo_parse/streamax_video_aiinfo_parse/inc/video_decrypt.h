#pragma once

#include <string>
#include <cryptopp/aes.h>
#include <cryptopp/modes.h>
#include <cryptopp/filters.h>

/**
 * @brief 视频帧解密类
 * 使用 CryptoPP 库进行 AES 解密
 */
class CVideoDecrypt
{
public:
    CVideoDecrypt();
    ~CVideoDecrypt();

    /**
     * @brief 从配置文件加载密钥
     * @param configPath 配置文件路径
     * @return 0-成功，-1-失败
     */
    int LoadKeyFromConfig(const std::string &configPath);

    /**
     * @brief 设置密钥
     * @param key 密钥字符串（十六进制或直接字符串）
     * @param keyLen 密钥长度（字节）
     * @return 0-成功，-1-失败
     */
    int SetKey(const unsigned char *key, int keyLen);

    /**
     * @brief 解密视频帧数据
     * @param encryptedData 加密的数据
     * @param dataLen 数据长度
     * @param decryptedData 输出解密后的数据（需要预先分配足够空间）
     * @param aesType AES类型：0-AES128, 1-AES192, 2-AES256
     * @return 解密后的数据长度，失败返回-1
     */
    int DecryptFrame(const unsigned char *encryptedData, int dataLen, 
                     unsigned char *decryptedData, int aesType);

private:
    unsigned char m_key[32];  // 最大支持 AES256
    int m_keyLen;
    bool m_keySet;
};

