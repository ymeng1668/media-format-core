#pragma once

#if defined(USE_OPENCV)
#include <opencv2/opencv.hpp>
#include "rmai_info_parse_struct_protocol.h"

/**
 * @brief 叠加绘制器（直接读取 Struct 算法组数据）
 */
class COverlayDrawer
{
public:
    COverlayDrawer();
    ~COverlayDrawer();

    /**
     * @brief 在图像上绘制单个算法组的 Struct 叠加信息
     * @param mat 输入图像（会被修改）
     * @param group 算法组头
     * @param buffer 完整 Struct buffer（group 偏移基于此 buffer）
     * @param aiPts AI PTS
     * @param overlayIndex 叠加项索引（多组时避免 ai_pts 文本重叠）
     * @param pStatusLineOffset 跨组 status 行累计偏移（自下而上堆叠，可为 NULL）
     * @return 0-成功绘制，-1-无可绘制内容或失败
     */
    int DrawOverlayFromGroup(cv::Mat &mat,
                             const RMAI_AlgGroupHeader* group,
                             const uint8_t* buffer,
                             unsigned long long aiPts = 0,
                             int overlayIndex = 0,
                             int* pStatusLineOffset = NULL,
                             bool hasFrontVehicleSpeed = false,
                             float frontVehicleSpeedKmh = 0.f);

    void DrawRect(cv::Mat &mat, int x, int y, int width, int height,
                  const cv::Scalar &color = cv::Scalar(0, 255, 0), int thickness = 2);

    void DrawPoint(cv::Mat &mat, int x, int y,
                   const cv::Scalar &color = cv::Scalar(0, 0, 255), int radius = 3);

    void DrawText(cv::Mat &mat, const std::string &text, int x, int y,
                  const cv::Scalar &color = cv::Scalar(255, 255, 255),
                  double scale = 0.5, int thickness = 2);

private:
    void DrawRectBlock(cv::Mat &mat,
                       const RMAI_AlgGroupDataBlockHeader* block,
                       const uint8_t* payload_base,
                       const cv::Scalar &color);

    void DrawPointBlock(cv::Mat &mat,
                        const RMAI_AlgGroupDataBlockHeader* block,
                        const uint8_t* payload_base,
                        const cv::Scalar &color,
                        int point_radius);

    void DrawSeatbeltContours(cv::Mat &mat,
                              const RMAI_AlgGroupDataBlockHeader* block,
                              const uint8_t* payload_base);
};

#endif  // USE_OPENCV
