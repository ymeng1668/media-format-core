# Windows 交付构建环境约束（VS2026 基线）

set(RMAI_WIN_MIN_CMAKE_VERSION "3.16")
set(RMAI_WIN_MIN_MSVC_VERSION 1950)
set(RMAI_WIN_MIN_WINDOWS_SDK_VERSION "10.0.26100.0")

if(NOT WIN32)
    return()
endif()

if(NOT MSVC)
    message(FATAL_ERROR
        "Windows 构建必须使用 MSVC (cl.exe)。\n"
        "请从「x64/x86 Native Tools Command Prompt for VS 2026」或等效环境中配置/编译。")
endif()

if(MSVC_VERSION LESS ${RMAI_WIN_MIN_MSVC_VERSION})
    message(FATAL_ERROR
        "MSVC 版本过低: ${MSVC_VERSION}。\n"
        "最低要求: Visual Studio 2026 (MSVC 14.50, MSVC_VERSION >= ${RMAI_WIN_MIN_MSVC_VERSION})。")
endif()

if(DEFINED CMAKE_VS_WINDOWS_TARGET_PLATFORM_VERSION
   AND NOT "${CMAKE_VS_WINDOWS_TARGET_PLATFORM_VERSION}" STREQUAL "")
    if(CMAKE_VS_WINDOWS_TARGET_PLATFORM_VERSION VERSION_LESS "${RMAI_WIN_MIN_WINDOWS_SDK_VERSION}")
        message(FATAL_ERROR
            "Windows SDK 版本过低: ${CMAKE_VS_WINDOWS_TARGET_PLATFORM_VERSION}。\n"
            "最低要求: ${RMAI_WIN_MIN_WINDOWS_SDK_VERSION}。")
    endif()
    message(STATUS "Windows SDK: ${CMAKE_VS_WINDOWS_TARGET_PLATFORM_VERSION}")
else()
    message(WARNING
        "未显式设置 CMAKE_VS_WINDOWS_TARGET_PLATFORM_VERSION，请使用 CMakePresets。")
endif()

if(CMAKE_SIZEOF_VOID_P EQUAL 8)
    set(RMAI_CURRENT_PLATFORM "x64")
else()
    set(RMAI_CURRENT_PLATFORM "x86")
endif()

message(STATUS "MSVC version: ${MSVC_VERSION}")
message(STATUS "Current Platform: ${RMAI_CURRENT_PLATFORM}")
message(STATUS "Windows toolchain check: PASSED")
