#!/bin/bash
set -e

PLATFORM_LIST=(
    "x86_64_gcc_13_3_0"
    "x64_msvc_2026"
    "x86_msvc_2026"
)

resolve_platform_key() {
    if [ -n "${RMAI_PLATFORM_KEY}" ]; then
        echo "${RMAI_PLATFORM_KEY}"
        return
    fi

    # 兼容旧用法: ./build.sh linux-release | x64-release | ...
    if [ -n "${1}" ]; then
        case "${1}" in
            linux-*)
                echo "x86_64_gcc_13_3_0"
                return
                ;;
            x64-*)
                echo "x64_msvc_2026"
                return
                ;;
            x86-*)
                echo "x86_msvc_2026"
                return
                ;;
        esac
    fi

    echo "platform:" >&2
    for i in "${!PLATFORM_LIST[@]}"; do
        echo " ${i}: ${PLATFORM_LIST[$i]}" >&2
    done
    echo -ne "please input platform id [0]: " >&2
    read _platform_
    _platform_="${_platform_:-0}"

    if [ "${_platform_}" -lt "${#PLATFORM_LIST[@]}" ] 2>/dev/null; then
        echo "${PLATFORM_LIST[_platform_]}"
    else
        echo "invalid platform id: ${_platform_}" >&2
        exit 1
    fi
}

resolve_build_cfg() {
    local preset_arg="${1:-}"

    if [ -n "${RMAI_BUILD_CFG}" ]; then
        echo "${RMAI_BUILD_CFG}"
        return
    fi

    if [[ "${preset_arg}" == *"-debug" ]]; then
        echo "debug"
        return
    fi
    if [[ "${preset_arg}" == *"-release" ]]; then
        echo "release"
        return
    fi

    echo "build type:" >&2
    echo " 1: release (default)" >&2
    echo " 2: debug" >&2
    echo -ne "please input build type id [1]: " >&2
    read _cfg_
    if [ "${_cfg_}" = "2" ]; then
        echo "debug"
    else
        echo "release"
    fi
}

PLATFORM_KEY="$(resolve_platform_key "${1:-}")"
BUILD_CFG="$(resolve_build_cfg "${1:-}")"

case "${PLATFORM_KEY}" in
    x86_64_gcc_13_3_0)
        PRESET="linux-${BUILD_CFG}"
        export RMAI_PLATFORM_KEY="${PLATFORM_KEY}"
        export RMAI_PRODUCT_TYPE="${PLATFORM_KEY}"
        # python3 scripts/streamax_deps.py check --platform linux --product-type "${PLATFORM_KEY}"
        cmake --preset "${PRESET}" -DRMAI_PRODUCT_TYPE="${PLATFORM_KEY}"
        cmake --build --preset "${PRESET}"
        # python3 scripts/streamax_deps.py deploy --platform linux --product-type "${PLATFORM_KEY}"
        ;;
    x64_msvc_2026)
        PRESET="x64-${BUILD_CFG}"
        export RMAI_PLATFORM_KEY="${PLATFORM_KEY}"
        cmd //c "build_windows.bat x64 ${BUILD_CFG}"
        ;;
    x86_msvc_2026)
        PRESET="x86-${BUILD_CFG}"
        export RMAI_PLATFORM_KEY="${PLATFORM_KEY}"
        cmd //c "build_windows.bat x86 ${BUILD_CFG}"
        ;;
    *)
        echo "unsupported platform key: ${PLATFORM_KEY}" >&2
        echo "用法: $0 [linux-release|x64-release|x86-release|...]" >&2
        echo "或设置 RMAI_PLATFORM_KEY=x86_64_gcc_13_3_0|x64_msvc_2026|x86_msvc_2026" >&2
        exit 1
        ;;
esac

echo "Build finished: platform=${PLATFORM_KEY} preset=${PRESET}"
