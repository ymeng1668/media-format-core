@echo off

setlocal EnableDelayedExpansion



REM Usage:

REM   build_windows.bat [x64_msvc_2026|x86_msvc_2026|x64|x86] [debug|release]

REM   build_windows.bat                         (interactive, same as build.sh)

REM Env: RMAI_PLATFORM_KEY, RMAI_BUILD_CFG



set "VS2026=D:\software_install\VS2026_community"

if not exist "%VS2026%\VC\Auxiliary\Build\vcvarsall.bat" (

    echo [ERROR] VS2026 not found

    exit /b 1

)



REM python "%~dp0scripts\streamax_deps.py" resolve-build %1 %2 > "%RESOLVE_FILE%"
if defined RMAI_PLATFORM_KEY (
    for /f "tokens=1 delims=_" %%a in ("!RMAI_PLATFORM_KEY!") do set "RMAI_ARCH=%%a"
    if not defined RMAI_CFG set "RMAI_CFG=release"
) else if /i "%1"=="x86" (
    set "RMAI_PLATFORM_KEY=x86_msvc_2026"
    set "RMAI_ARCH=x86"
    set "RMAI_CFG=%2"
) else if /i "%1"=="x86_msvc_2026" (
    set "RMAI_PLATFORM_KEY=x86_msvc_2026"
    set "RMAI_ARCH=x86"
    set "RMAI_CFG=%2"
) else if /i "%1"=="x64" (
    set "RMAI_PLATFORM_KEY=x64_msvc_2026"
    set "RMAI_ARCH=x64"
    set "RMAI_CFG=%2"
) else if /i "%1"=="x64_msvc_2026" (
    set "RMAI_PLATFORM_KEY=x64_msvc_2026"
    set "RMAI_ARCH=x64"
    set "RMAI_CFG=%2"
) else (
    set "RMAI_PLATFORM_KEY=x64_msvc_2026"
    set "RMAI_ARCH=x64"
    set "RMAI_CFG=%1"
)
if /i "!RMAI_CFG!"=="" set "RMAI_CFG=release"
if /i "!RMAI_CFG!"=="debug" set "RMAI_CFG=debug"
if /i not "!RMAI_CFG!"=="debug" set "RMAI_CFG=release"
if not defined RMAI_PLATFORM_KEY (
    echo [ERROR] failed to resolve platform key
    exit /b 1
)



set "PRESET=!RMAI_ARCH!-!RMAI_CFG!"



REM python "%~dp0scripts\streamax_deps.py" check --platform windows --platform-key !RMAI_PLATFORM_KEY!



if /i "!RMAI_ARCH!"=="x86" (

    call "%VS2026%\VC\Auxiliary\Build\vcvarsall.bat" x86

) else (

    call "%VS2026%\VC\Auxiliary\Build\vcvarsall.bat" x64

)



cmake --preset !PRESET! -DRMAI_PLATFORM_KEY=!RMAI_PLATFORM_KEY!

if errorlevel 1 exit /b 1



cmake --build --preset !PRESET!

if errorlevel 1 exit /b 1



REM python "%~dp0scripts\streamax_deps.py" deploy --platform windows --platform-key !RMAI_PLATFORM_KEY!



echo === Build finished: !RMAI_PLATFORM_KEY! !PRESET! ===

endlocal


