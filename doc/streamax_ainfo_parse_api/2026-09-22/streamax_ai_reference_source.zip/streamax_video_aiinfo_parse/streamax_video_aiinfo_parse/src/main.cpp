#include <stdio.h>
#include <string.h>
#include <string>
#include "func.h"
#include "rmai_info_parse_api.h"

// Declare video processing function
extern "C" int ProcessVideoWithOverlay(const char *videoPath, const char *textPath,
                                       const char *outputPath, const char *configPath);

/**
 * @brief Replace file extension
 * @param filePath Original file path
 * @param newExt New extension (without dot)
 * @return New file path
 */
std::string ReplaceFileExtension(const char *filePath, const char *newExt)
{
    std::string path(filePath);

    // Find last dot position
    size_t dotPos = path.rfind('.');
    if (dotPos != std::string::npos)
    {
        // Check if it's .264 or .265
        std::string ext = path.substr(dotPos);
        if (ext == ".264" || ext == ".265" || ext == ".h264" || ext == ".h265")
        {
            path = path.substr(0, dotPos);
        }
    }

    path += ".";
    path += newExt;
    return path;
}

int Ana264(void* pars, char *filePath)
{
	FILE *fileSrc;
	fileSrc = fopen(filePath, "rb");
	if (fileSrc == NULL)
	{
		printf("open demo.264 failed \n");
		return -1;
	}

	long long ullReaded = 0;
	long long fileLen = 0;
	int   bEnd = false;
	int   nBufLen = 2000000;
	char*  pBuf = new char[nBufLen];
	int nReadLen = 0; 	//ʵ�ʶ�ȡ���ļ����ݳ���
	int nRemain = 0; 	//nRemain�����ڱ�ʾpBuf��ʣ��Ĵ�����264/265�ļ����ݳ���
	bool noFoundFrame = true;
	char* pPos = NULL;
	VIDEO_DATA data;
	int nRet = 0;

	//��ȡ�ļ�����
	fseek(fileSrc, 0, SEEK_END);
	fileLen = ftell(fileSrc);
	fseek(fileSrc, 0, SEEK_SET);

	RMAI_HANDLE handle = RMAI_INVALID_HANDLE;
	RMAI_ImageSize imageSize;
	imageSize.width = 2592;  //Ŀ��ͼ��Ĵ�С��2592*1920�����ú󣬽������ĵ��ӿ����������ߣ������ŵ��óߴ��ͼ���С�
	imageSize.height = 1920;
	handle = RMAIInfo_Parse_Create(imageSize);
	if (handle == RMAI_INVALID_HANDLE)
	{
		printf("RMAIInfo_Parse_Create failed\n");
		fclose(fileSrc);
		fileSrc = NULL;
		delete[] pBuf;
		pBuf = NULL;
		return -1;
	}

	while (1)
	{
		/// ��ȡ�ļ���
		if (nRemain < 24 || noFoundFrame)
		{
			if (bEnd) break;
			nReadLen = (int)fread(pBuf + nRemain, 1, nBufLen - nRemain, fileSrc);

			if (nReadLen < nBufLen - nRemain)
			{
				bEnd = true; //�ļ���β
			}
			if (nReadLen < 1) break;
			nRemain = nReadLen + nRemain; //nRemain�����ڱ�ʾpBuf��ʣ��Ĵ��������ݳ���
			pPos = pBuf;
		}

		///  ��������
		nRet = gAnalyseData0(&pPos, nRemain, &data); //����֡ͷ����ȡ�����ڴ�����ݵ�ַ
		if (nRet == 2)   //nRet = 2ʱ��pBuf��ʣ��nRemain���ֽ������Ѳ����������������Ҫ������ȡ
		{
			memcpy(pBuf, pPos, nRemain);
			noFoundFrame = true;
			continue;
		}

		noFoundFrame = false;
		parse_aiInfo_body(pars, &data, handle); //�ӵ����ڴ���н���AI����

		pPos += data.nTotalLen;
		nRemain -= data.nTotalLen;
	}

	RMAIInfo_Parse_Destroy(handle);

	fclose(fileSrc);
	fileSrc = NULL;
	delete[] pBuf;
	pBuf = NULL;

	if (nRet == -2)
		return nRet;	// ��Ƶ����ʧ��

	return 0;
}

// ԭ�еĽ��� AI ��Ϣ���ܣ�������
int ParseAiInfoOnly(int argc, char* argv[])
{
	if (argc < 2)
	{
		return -1;
	}

	char *file264Path = argv[1];

	ai_info_outtext_vars vars;
	FILE* fp;

	printf("Parse aiInfo start!\r\n");
	vars.fileAvi = fopen("aiInfo.txt", "wb+");     /// ���ӽ���������Ϣд��aiInfo.txt
	if (!vars.fileAvi)
	{
		printf("Parse aiInfo end: aiInfo.txt opened failed !!\n");
		return 1;
	}

	vars.summary_lines.clear();
	vars.stats = StructParseStats();
	vars.frame_index = 0;

	int retv = Ana264(&vars, file264Path);
	if(retv != 0)
	{
		printf("Parse aiInfo end: analyze 264/265 failed !!\n");
		fclose(vars.fileAvi);
		vars.fileAvi = NULL;
		return 1;
	}

	fclose(vars.fileAvi);
	vars.fileAvi = NULL;

	print_struct_stats(vars.stats);

	FILE* summaryFile = fopen("aiInfo_summary.txt", "wb+");
	if (NULL != summaryFile)
	{
		for (size_t i = 0; i < vars.summary_lines.size(); ++i)
		{
			const std::string& line = vars.summary_lines[i];
			fwrite(line.c_str(), 1, line.length(), summaryFile);
		}
		fclose(summaryFile);
		summaryFile = NULL;
	}
	else
	{
		printf("Parse aiInfo end: aiInfo_summary.txt opened failed !!\n");
		return 1;
	}

	printf("Parse aiInfo end!\r\n");

	return 0;
}

int main(int argc, char* argv[])
{
	// ����������� --parse-only����ֻ���� AI ��Ϣ
	if (argc >= 2 && strcmp(argv[1], "--parse-only") == 0)
	{
		// �����������Ƴ� --parse-only
		char* new_argv[10];
		int new_argc = 0;
		new_argv[new_argc++] = argv[0];
		for (int i = 2; i < argc && i < 10; ++i)
		{
			new_argv[new_argc++] = argv[i];
		}
		return ParseAiInfoOnly(new_argc, new_argv);
	}

	// Otherwise use new video processing feature
#if defined(USE_OPENCV)
	// Use new video processing feature
	extern int ProcessVideoWithOverlay(const char *videoPath, const char *textPath,
	                                   const char *outputPath, const char *configPath);

	if (argc < 2)
	{
		printf("Usage: %s <video_file> [config_file]\n", argv[0]);
		printf("  video_file:  Input video file (.264/.265 format)\n");
		printf("  config_file: Decrypt config file (optional)\n");
		printf("\nOutput files will be auto-generated:\n");
		printf("  - MP4 file: Replace video extension with .mp4\n");
		printf("  - Text summary: Replace video extension with .txt\n");
		printf("\nOr use --parse-only mode to parse AI info only:\n");
		printf("  %s --parse-only <video_file>\n", argv[0]);
		return -1;
	}

	const char *videoPath = argv[1];
	const char *configPath = (argc >= 3) ? argv[2] : NULL;

	// Auto-generate output filenames
	std::string outputMp4Path = ReplaceFileExtension(videoPath, "mp4");
	std::string outputTextPath = ReplaceFileExtension(videoPath, "txt");

	printf("========== Processing Parameters ==========\n");
	printf("Input video: %s\n", videoPath);
	if (NULL != configPath)
	{
		printf("Config file: %s\n", configPath);
	}
	printf("Output MP4:  %s\n", outputMp4Path.c_str());
	printf("Output text: %s\n", outputTextPath.c_str());
	printf("============================================\n\n");

	int ret = ProcessVideoWithOverlay(videoPath, outputTextPath.c_str(),
	                                   outputMp4Path.c_str(), configPath);
	if (ret != 0)
	{
		printf("Processing failed\n");
		return 1;
	}

	printf("Finished!\n");
	return 0;
#else
	// OpenCV not enabled, can only parse AI info
	printf("OpenCV not enabled, using parse-only mode\n");
	return ParseAiInfoOnly(argc, argv);
#endif
}