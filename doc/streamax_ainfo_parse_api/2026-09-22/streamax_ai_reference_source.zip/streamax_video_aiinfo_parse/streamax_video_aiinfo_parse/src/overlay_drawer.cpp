#if defined(USE_OPENCV)
#include "overlay_drawer.h"
#include "struct_decode.h"
#include <iostream>
#include <string>
#include <vector>

COverlayDrawer::COverlayDrawer()
{
}

COverlayDrawer::~COverlayDrawer()
{
}

void COverlayDrawer::DrawRect(cv::Mat &mat, int x, int y, int width, int height,
                              const cv::Scalar &color, int thickness)
{
    cv::rectangle(mat, cv::Point(x, y), cv::Point(x + width, y + height), color, thickness);
}

void COverlayDrawer::DrawPoint(cv::Mat &mat, int x, int y, const cv::Scalar &color, int radius)
{
    cv::circle(mat, cv::Point(x, y), radius, color, -1);
}

void COverlayDrawer::DrawText(cv::Mat &mat, const std::string &text, int x, int y,
                              const cv::Scalar &color, double scale, int thickness)
{
    cv::putText(mat, text, cv::Point(x, y), cv::FONT_HERSHEY_SIMPLEX, scale, color, thickness);
}

void COverlayDrawer::DrawRectBlock(cv::Mat &mat,
                                   const RMAI_AlgGroupDataBlockHeader* block,
                                   const uint8_t* payload_base,
                                   const cv::Scalar &color)
{
    if (NULL == block || 0 == block->count || block->elem_size != sizeof(RMAI_Rect))
    {
        return;
    }

    const RMAI_Rect* rects = (const RMAI_Rect*)(payload_base + block->data_offset);
    for (uint32_t i = 0; i < block->count; ++i)
    {
        DrawRect(mat, rects[i].x, rects[i].y, rects[i].width, rects[i].height, color, 2);
    }
}

void COverlayDrawer::DrawPointBlock(cv::Mat &mat,
                                    const RMAI_AlgGroupDataBlockHeader* block,
                                    const uint8_t* payload_base,
                                    const cv::Scalar &color,
                                    int point_radius)
{
    if (NULL == block || 0 == block->count || block->elem_size != sizeof(RMAI_Point))
    {
        return;
    }

    const RMAI_Point* points = (const RMAI_Point*)(payload_base + block->data_offset);
    for (uint32_t i = 0; i < block->count; ++i)
    {
        DrawPoint(mat, points[i].x, points[i].y, color, point_radius);
    }
}

void COverlayDrawer::DrawSeatbeltContours(cv::Mat &mat,
                                          const RMAI_AlgGroupDataBlockHeader* block,
                                          const uint8_t* payload_base)
{
    if (NULL == block || 0 == block->count || 0 != block->elem_size)
    {
        return;
    }

    const uint8_t* p = payload_base + block->data_offset;
    const uint8_t* end = p + block->data_size;

    for (uint32_t ci = 0; ci < block->count; ++ci)
    {
        if (p + sizeof(RMAI_ContourHeader) > end)
        {
            break;
        }

        const RMAI_ContourHeader* header = (const RMAI_ContourHeader*)p;
        p += sizeof(RMAI_ContourHeader);

        size_t point_bytes = header->point_count * sizeof(RMAI_Point);
        if (p + point_bytes > end || header->point_count < 2)
        {
            break;
        }

        const RMAI_Point* points = (const RMAI_Point*)p;
        std::vector<cv::Point> cv_points;
        for (uint32_t pi = 0; pi < header->point_count; ++pi)
        {
            cv_points.push_back(cv::Point(points[pi].x, points[pi].y));
        }

        for (size_t i = 0; i + 1 < cv_points.size(); ++i)
        {
            cv::line(mat, cv_points[i], cv_points[i + 1], cv::Scalar(0, 255, 255), 2);
        }
        cv::line(mat, cv_points.back(), cv_points.front(), cv::Scalar(0, 255, 255), 2);

        p += point_bytes;
    }
}

int COverlayDrawer::DrawOverlayFromGroup(cv::Mat &mat,
                                         const RMAI_AlgGroupHeader* group,
                                         const uint8_t* buffer,
                                         unsigned long long aiPts,
                                         int overlayIndex,
                                         int* pStatusLineOffset,
                                         bool hasFrontVehicleSpeed,
                                         float frontVehicleSpeedKmh)
{
    if (NULL == group || NULL == buffer || mat.empty())
    {
        return -1;
    }

    const RMAI_AlgOutputHeader* hdr = (const RMAI_AlgOutputHeader*)buffer;
    if (group->payload_offset + group->payload_size > hdr->total_size)
    {
        return -1;
    }

    if (group->payload_size < sizeof(RMAI_AlgGroupPayloadHeader))
    {
        return -1;
    }

    const uint8_t* payload_base = buffer + group->payload_offset;
    const RMAI_AlgGroupPayloadHeader* ph = (const RMAI_AlgGroupPayloadHeader*)payload_base;

    bool drewSomething = false;

    const RMAI_AlgGroupDataBlockHeader* vehicles =
        find_data_block(payload_base, ph, RMAI_ADAS_VEHICLES);
    if (NULL != vehicles && vehicles->count > 0 &&
        vehicles->elem_size == sizeof(RMAI_Vehicle))
    {
        const RMAI_Vehicle* vehicle_list =
            (const RMAI_Vehicle*)(payload_base + vehicles->data_offset);
        for (uint32_t i = 0; i < vehicles->count; ++i)
        {
            const RMAI_Vehicle& vehicle = vehicle_list[i];
            cv::Scalar color = vehicle.is_target ? cv::Scalar(0, 0, 255) : cv::Scalar(0, 255, 255);
            DrawRect(mat, vehicle.x, vehicle.y, vehicle.width, vehicle.height, color, 2);
            if (vehicle.is_target)
            {
                DrawText(mat, "TARGET", vehicle.x, vehicle.y - 5, cv::Scalar(0, 0, 255), 1.0, 2);
            }
            if (vehicle.flags & 0x01)
            {
                char distText[32];
                snprintf(distText, sizeof(distText), "%.1fm", vehicle.distance);
                DrawText(mat, distText, vehicle.x, vehicle.y + vehicle.height + 20, color, 1.0, 2);
            }
            if (vehicle.is_target && hasFrontVehicleSpeed)
            {
                int speedY = vehicle.y + vehicle.height + 20;
                if (vehicle.flags & 0x01)
                {
                    speedY += 25;
                }
                char speedText[32];
                snprintf(speedText, sizeof(speedText), "%.1fkm/h", frontVehicleSpeedKmh);
                DrawText(mat, speedText, vehicle.x, speedY, color, 1.0, 2);
            }
        }
        drewSomething = true;
    }

    const RMAI_AlgGroupDataBlockHeader* pedestrians =
        find_data_block(payload_base, ph, RMAI_ADAS_PEDESTRIANS);
    if (NULL != pedestrians && pedestrians->count > 0 &&
        pedestrians->elem_size == sizeof(RMAI_Pedestrian))
    {
        const RMAI_Pedestrian* pedestrian_list =
            (const RMAI_Pedestrian*)(payload_base + pedestrians->data_offset);
        for (uint32_t i = 0; i < pedestrians->count; ++i)
        {
            const RMAI_Pedestrian& pedestrian = pedestrian_list[i];
            cv::Scalar color = pedestrian.is_target ? cv::Scalar(255, 0, 255) : cv::Scalar(255, 255, 0);
            DrawRect(mat, pedestrian.x, pedestrian.y, pedestrian.width, pedestrian.height, color, 2);
            if (pedestrian.is_target)
            {
                DrawText(mat, "TARGET", pedestrian.x, pedestrian.y - 5, cv::Scalar(255, 0, 255), 0.8, 2);
            }
            if (pedestrian.flags & 0x01)
            {
                char distText[32];
                snprintf(distText, sizeof(distText), "%.1fm", pedestrian.distance);
                DrawText(mat, distText, pedestrian.x, pedestrian.y + pedestrian.height + 20,
                         color, 1.0, 2);
            }
        }
        drewSomething = true;
    }

    const RMAI_AlgGroupDataBlockHeader* left_lane =
        find_data_block(payload_base, ph, RMAI_ADAS_LEFT_LANE_POINTS);
    if (NULL != left_lane && left_lane->count >= 2)
    {
        const RMAI_Point* points = (const RMAI_Point*)(payload_base + left_lane->data_offset);
        for (uint32_t i = 0; i + 1 < left_lane->count; ++i)
        {
            cv::line(mat, cv::Point(points[i].x, points[i].y),
                     cv::Point(points[i + 1].x, points[i + 1].y),
                     cv::Scalar(0, 255, 0), 3);
        }
        drewSomething = true;
    }

    const RMAI_AlgGroupDataBlockHeader* right_lane =
        find_data_block(payload_base, ph, RMAI_ADAS_RIGHT_LANE_POINTS);
    if (NULL != right_lane && right_lane->count >= 2)
    {
        const RMAI_Point* points = (const RMAI_Point*)(payload_base + right_lane->data_offset);
        for (uint32_t i = 0; i + 1 < right_lane->count; ++i)
        {
            cv::line(mat, cv::Point(points[i].x, points[i].y),
                     cv::Point(points[i + 1].x, points[i + 1].y),
                     cv::Scalar(0, 255, 0), 3);
        }
        drewSomething = true;
    }

    const RMAI_AlgGroupDataBlockHeader* rolling_stop =
        find_data_block(payload_base, ph, RMAI_ADAS_ROLLING_STOP_COORDS);
    if (NULL != rolling_stop)
    {
        DrawRectBlock(mat, rolling_stop, payload_base, cv::Scalar(0, 165, 255));
        drewSomething = true;
    }

    const RMAI_AlgGroupDataBlockHeader* speed_limit =
        find_data_block(payload_base, ph, RMAI_ADAS_SPEED_LIMIT_SIGN_COORDS);
    if (NULL != speed_limit)
    {
        DrawRectBlock(mat, speed_limit, payload_base, cv::Scalar(255, 0, 0));
        drewSomething = true;
    }

    const RMAI_AlgGroupDataBlockHeader* detection_area =
        find_data_block(payload_base, ph, RMAI_ADAS_DETECTION_AREA);
    if (NULL != detection_area)
    {
        DrawRectBlock(mat, detection_area, payload_base, cv::Scalar(255, 255, 255));
        drewSomething = true;
    }

    const RMAI_AlgGroupDataBlockHeader* dsc_detection_area =
        find_data_block(payload_base, ph, RMAI_DSC_DETECTION_AREA);
    if (NULL != dsc_detection_area)
    {
        DrawRectBlock(mat, dsc_detection_area, payload_base, cv::Scalar(255, 255, 255));
        drewSomething = true;
    }

    const RMAI_AlgGroupDataBlockHeader* face_rects =
        find_data_block(payload_base, ph, RMAI_DSC_FACE_RECTS);
    if (NULL != face_rects)
    {
        DrawRectBlock(mat, face_rects, payload_base, cv::Scalar(0, 255, 0));
        drewSomething = true;
    }

    const RMAI_AlgGroupDataBlockHeader* face_key_points =
        find_data_block(payload_base, ph, RMAI_DSC_FACE_KEY_POINTS);
    if (NULL != face_key_points)
    {
        DrawPointBlock(mat, face_key_points, payload_base, cv::Scalar(0, 0, 255), 3);
        drewSomething = true;
    }

    const RMAI_AlgGroupDataBlockHeader* phone_rects =
        find_data_block(payload_base, ph, RMAI_DSC_PHONE_RECTS);
    if (NULL != phone_rects)
    {
        DrawRectBlock(mat, phone_rects, payload_base, cv::Scalar(255, 255, 0));
        drewSomething = true;
    }

    const RMAI_AlgGroupDataBlockHeader* seatbelt =
        find_data_block(payload_base, ph, RMAI_DSC_SEATBELT_CONTOURS);
    if (NULL != seatbelt && seatbelt->count > 0)
    {
        DrawSeatbeltContours(mat, seatbelt, payload_base);
        drewSomething = true;
    }

    const RMAI_AlgGroupDataBlockHeader* head_pose_block =
        find_data_block(payload_base, ph, RMAI_DSC_HEAD_POSE);
    if (NULL != head_pose_block && head_pose_block->count > 0 &&
        head_pose_block->elem_size == sizeof(RMAI_HeadPose))
    {
        const RMAI_HeadPose* head_pose =
            (const RMAI_HeadPose*)(payload_base + head_pose_block->data_offset);
        int leftX = 10;
        int middleY = mat.rows / 2;
        int lineHeight = 30;
        int startY = middleY - lineHeight;

        char yawText[64];
        char pitchText[64];
        char rollText[64];
        snprintf(yawText, sizeof(yawText), "Yaw: %.2f", head_pose->yaw);
        snprintf(pitchText, sizeof(pitchText), "Pitch: %.2f", head_pose->pitch);
        snprintf(rollText, sizeof(rollText), "Roll: %.2f", head_pose->roll);

        DrawText(mat, yawText, leftX, startY, cv::Scalar(255, 255, 0), 1.0, 2);
        DrawText(mat, pitchText, leftX, startY + lineHeight, cv::Scalar(255, 255, 0), 1.0, 2);
        DrawText(mat, rollText, leftX, startY + lineHeight * 2, cv::Scalar(255, 255, 0), 1.0, 2);
        drewSomething = true;
    }

    const RMAI_AlgGroupDataBlockHeader* dsc_speed =
        find_data_block(payload_base, ph, RMAI_DSC_VECHILE_SPEED);
    if (NULL != dsc_speed && 1 == dsc_speed->count &&
        dsc_speed->elem_size == sizeof(RMAI_VechileSpeed))
    {
        const RMAI_VechileSpeed* speed_item =
            (const RMAI_VechileSpeed*)(payload_base + dsc_speed->data_offset);
        char speedText[48];
        snprintf(speedText, sizeof(speedText), "Speed: %d km/h", speed_item->speed);
        DrawText(mat, speedText, 10, 30, cv::Scalar(0, 255, 255), 1.0, 2);
        drewSomething = true;
    }

    const RMAI_AlgGroupDataBlockHeader* alarms =
        find_data_block(payload_base, ph, RMAI_ALG_ALARMS);
    if (NULL != alarms && alarms->count > 0 &&
        alarms->elem_size == sizeof(RMAI_AlarmItem))
    {
        const RMAI_AlarmItem* alarm_list =
            (const RMAI_AlarmItem*)(payload_base + alarms->data_offset);

        int centerX = mat.cols / 2;
        int centerY = mat.rows / 2;
        int yPos = centerY - (int)(alarms->count * 40) / 2;

        for (uint32_t i = 0; i < alarms->count; ++i)
        {
            std::string alarmType = alarm_type_name(alarm_list[i].alarm_type);
            int fontFace = cv::FONT_HERSHEY_SIMPLEX;
            double fontScale = 1.5;
            int thickness = 3;
            int baseline = 0;
            cv::Size textSize = cv::getTextSize(alarmType, fontFace, fontScale, thickness, &baseline);
            int textX = centerX - textSize.width / 2;

            cv::Rect bgRect(textX - 10, yPos - textSize.height - 5,
                            textSize.width + 20, textSize.height + 15);
            cv::Mat roi = mat(bgRect);
            cv::Mat colorMat(roi.size(), roi.type(), cv::Scalar(0, 0, 0));
            cv::addWeighted(roi, 0.5, colorMat, 0.5, 0, roi);

            DrawText(mat, alarmType, textX, yPos, cv::Scalar(0, 0, 255), fontScale, thickness);
            yPos += 50;
        }
        drewSomething = true;
    }

    const RMAI_AlgGroupDataBlockHeader* status_block =
        find_data_block(payload_base, ph, RMAI_ADAS_STATUS);
    if (NULL != status_block && status_block->count > 0 &&
        status_block->elem_size == sizeof(RMAI_StatusItem))
    {
        const RMAI_StatusItem* status_list =
            (const RMAI_StatusItem*)(payload_base + status_block->data_offset);
        const int kStatusBaseFromBottom = 125;
        const int kStatusLineHeight = 35;
        int lineOffset = (NULL != pStatusLineOffset) ? *pStatusLineOffset : 0;

        for (uint32_t i = 0; i < status_block->count; ++i)
        {
            int yPos = mat.rows - kStatusBaseFromBottom - lineOffset * kStatusLineHeight;
            std::string fullText = std::string(status_type_name(status_list[i].status_type))
                                   + ": " + status_list[i].text;
            DrawText(mat, fullText, 10, yPos, cv::Scalar(0, 255, 255), 1.0, 2);
            ++lineOffset;
        }

        if (NULL != pStatusLineOffset)
        {
            *pStatusLineOffset = lineOffset;
        }
        drewSomething = true;
    }

    if (aiPts > 0)
    {
        int middleY = mat.rows / 2;
        int yOffset = overlayIndex * 40;
        int yPos = middleY + yOffset;

        char infoText[128];
        snprintf(infoText, sizeof(infoText), "type:%s  ai_pts:%llu",
                 alg_type_json_name(group->alg_type), aiPts);
        DrawText(mat, infoText, 10, yPos, cv::Scalar(0, 255, 0), 1.0, 2);
        drewSomething = true;
    }

    return drewSomething ? 0 : -1;
}

#endif  // USE_OPENCV
