#pragma once

#include "rmai_info_parse_struct_protocol.h"
#include "struct_overlay_item.h"
#include <stdint.h>
#include <string>
#include <vector>

/** 解析统计 */
struct StructParseStats
{
    uint64_t parse_ok_count;
    uint64_t parse_fail_count;
    uint64_t empty_result_count;
    uint64_t total_groups;
    uint64_t total_alarms;

    StructParseStats()
        : parse_ok_count(0)
        , parse_fail_count(0)
        , empty_result_count(0)
        , total_groups(0)
        , total_alarms(0)
    {
    }
};

/** 文本摘要格式化选项 */
struct StructSummaryOptions
{
    bool include_vehicle_detail;
    bool include_pedestrian_detail;
    bool include_alarm_detail;
    bool include_status_detail;

    StructSummaryOptions()
        : include_vehicle_detail(true)
        , include_pedestrian_detail(true)
        , include_alarm_detail(true)
        , include_status_detail(true)
    {
    }
};

const RMAI_AlgGroupDataBlockHeader* find_data_block(
    const uint8_t* payload_base,
    const RMAI_AlgGroupPayloadHeader* ph,
    uint32_t want_block_type);

void update_struct_stats(const RMAI_StructOutput* out, StructParseStats* stats);

std::string format_struct_summary(
    const RMAI_StructOutput* out,
    uint64_t video_pts,
    uint64_t ai_pts,
    uint32_t frame_index,
    const StructSummaryOptions& opt,
    StructParseStats* stats);

/** 将 ParseStruct 输出拆分为按算法组的叠加项 */
void collect_overlay_groups(
    const RMAI_StructOutput* out,
    uint64_t ai_pts,
    int frame_index,
    std::vector<StructOverlayGroupItem>* items);

/** 判断算法组是否含可绘制内容 */
bool struct_group_has_content(
    const RMAI_AlgGroupHeader* group,
    const uint8_t* buffer);

const char* block_type_name(uint32_t block_type);
const char* alarm_type_name(uint32_t alarm_type);
const char* status_type_name(uint32_t status_type);
const char* alg_type_name(uint32_t alg_type);
/** 与原 JSON 顶层 type 字段一致的字符串（如 fcw_hmw） */
const char* alg_type_json_name(uint32_t alg_type);
const char* category_name(uint16_t category);

void print_struct_stats(const StructParseStats& stats);

/** Parse speed from status text such as "56km/h" or "4.5km/h". */
bool parse_status_speed_kmh(const char* text, float* out_kmh);

/**
 * When matched overlays contain both FCW_HMW and LDW with CAR_SPEED and
 * CAR_RELATIVE_SPEED status, compute front vehicle speed (km/h).
 */
bool compute_front_vehicle_speed_kmh(
    const std::vector<StructOverlayGroupItem>& overlays,
    float* out_front_speed_kmh);
