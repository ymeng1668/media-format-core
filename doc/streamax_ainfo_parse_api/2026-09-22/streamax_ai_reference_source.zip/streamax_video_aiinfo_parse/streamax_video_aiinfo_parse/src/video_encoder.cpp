#if defined(USE_OPENCV)
#include "video_encoder.h"
#include <stdio.h>
#include <string.h>

CVideoEncoder::CVideoEncoder()
{
    m_formatCtx = NULL;
    m_codecCtx = NULL;
    m_videoStream = NULL;
    m_frame = NULL;
    m_packet = NULL;
    m_swsCtx = NULL;
    m_width = 0;
    m_height = 0;
    m_fps = 25;
    m_frameIndex = 0;
    m_initialized = false;
}

CVideoEncoder::~CVideoEncoder()
{
    Finish();
}

int CVideoEncoder::InitEncoder(const std::string &outputPath, int width, int height, 
                                int fps, AVCodecID codecId)
{
    if (m_initialized)
    {
        Finish();
    }

    m_width = width;
    m_height = height;
    m_fps = fps;
    m_frameIndex = 0;

    // 分配输出上下文
    int ret = avformat_alloc_output_context2(&m_formatCtx, NULL, NULL, outputPath.c_str());
    if (ret < 0 || NULL == m_formatCtx)
    {
        fprintf(stderr, "Could not create output context\n");
        return -1;
    }

    // 查找编码器（优先使用软件编码器，跳过硬件编码器，最终回退到 MPEG-4）
    const AVCodec *codec = NULL;
    AVCodecID finalCodecId = codecId;

    if (codecId == AV_CODEC_ID_H264)
    {
        // 优先尝试 libx264 软件编码器
        codec = avcodec_find_encoder_by_name("libx264");
        if (NULL != codec)
        {
            printf("Using libx264 software encoder\n");
        }
        else
        {
            // libx264 不可用，直接使用 MPEG-4（跳过可能不可用的硬件编码器）
            printf("libx264 not found, falling back to MPEG-4 software encoder\n");
            finalCodecId = AV_CODEC_ID_MPEG4;
            codec = avcodec_find_encoder(finalCodecId);
        }
    }
    else if (codecId == AV_CODEC_ID_H265)
    {
        // 优先尝试 libx265 软件编码器
        codec = avcodec_find_encoder_by_name("libx265");
        if (NULL != codec)
        {
            printf("Using libx265 software encoder\n");
        }
        else
        {
            // libx265 不可用，直接使用 MPEG-4
            printf("libx265 not found, falling back to MPEG-4 software encoder\n");
            finalCodecId = AV_CODEC_ID_MPEG4;
            codec = avcodec_find_encoder(finalCodecId);
        }
    }
    else
    {
        codec = avcodec_find_encoder(codecId);
    }

    if (NULL == codec)
    {
        fprintf(stderr, "No suitable encoder found\n");
        return -1;
    }

    printf("Selected encoder: %s (codec_id: %d)\n", codec->name, finalCodecId);

    // 创建视频流
    m_videoStream = avformat_new_stream(m_formatCtx, codec);
    if (NULL == m_videoStream)
    {
        fprintf(stderr, "Could not create video stream\n");
        return -1;
    }

    // 分配编码器上下文
    m_codecCtx = avcodec_alloc_context3(codec);
    if (NULL == m_codecCtx)
    {
        fprintf(stderr, "Could not allocate codec context\n");
        return -1;
    }

    // 设置编码参数
    m_codecCtx->codec_id = finalCodecId;
    m_codecCtx->codec_type = AVMEDIA_TYPE_VIDEO;
    m_codecCtx->width = width;
    m_codecCtx->height = height;
    m_codecCtx->pix_fmt = AV_PIX_FMT_YUV420P;
    m_codecCtx->time_base.num = 1;
    m_codecCtx->time_base.den = fps;
    m_codecCtx->gop_size = 12;
    m_codecCtx->max_b_frames = 0;

    // 设置比特率（重要！MPEG-4需要指定比特率）
    if (finalCodecId == AV_CODEC_ID_MPEG4)
    {
        // 根据分辨率设置合适的比特率
        // 公式：width * height * fps * 比特率因子
        int64_t bitrate = (int64_t)width * height * fps / 10;  // 约3-5Mbps for 800x1280@20fps
        if (bitrate < 1000000) bitrate = 2000000;  // 最小2Mbps
        m_codecCtx->bit_rate = bitrate;
        m_codecCtx->rc_max_rate = bitrate * 2;
        m_codecCtx->rc_buffer_size = bitrate;
        printf("MPEG-4 bitrate set to: %lld bps (%.2f Mbps)\n", 
               (long long)bitrate, bitrate / 1000000.0);
    }
    else if (finalCodecId == AV_CODEC_ID_H264)
    {
        m_codecCtx->bit_rate = width * height * fps / 10;
    }

    if (m_formatCtx->oformat->flags & AVFMT_GLOBALHEADER)
    {
        m_codecCtx->flags |= AV_CODEC_FLAG_GLOBAL_HEADER;
    }

    // 设置编码器选项
    AVDictionary *opts = NULL;
    if (finalCodecId == AV_CODEC_ID_H264)
    {
        av_dict_set(&opts, "preset", "medium", 0);
        av_dict_set(&opts, "tune", "zerolatency", 0);
    }
    else if (finalCodecId == AV_CODEC_ID_MPEG4)
    {
        // MPEG-4 编码器参数
        av_dict_set(&opts, "q", "5", 0);  // 质量控制 (1-31, 值越小质量越高)
    }

    // 打开编码器
    ret = avcodec_open2(m_codecCtx, codec, &opts);
    av_dict_free(&opts);
    if (ret < 0)
    {
        fprintf(stderr, "Could not open codec\n");
        return -1;
    }

    // 复制编码器参数到流
    ret = avcodec_parameters_from_context(m_videoStream->codecpar, m_codecCtx);
    if (ret < 0)
    {
        fprintf(stderr, "Could not copy codec parameters\n");
        return -1;
    }

    m_videoStream->time_base.num = 1;
    m_videoStream->time_base.den = fps;

    // 打开输出文件
    if (!(m_formatCtx->oformat->flags & AVFMT_NOFILE))
    {
        ret = avio_open(&m_formatCtx->pb, outputPath.c_str(), AVIO_FLAG_WRITE);
        if (ret < 0)
        {
            fprintf(stderr, "Could not open output file\n");
            return -1;
        }
    }

    // 写入文件头
    ret = avformat_write_header(m_formatCtx, NULL);
    if (ret < 0)
    {
        fprintf(stderr, "Error writing header\n");
        return -1;
    }

    // 分配帧
    m_frame = av_frame_alloc();
    if (NULL == m_frame)
    {
        fprintf(stderr, "Could not allocate video frame\n");
        return -1;
    }

    m_frame->format = m_codecCtx->pix_fmt;
    m_frame->width = width;
    m_frame->height = height;

    ret = av_frame_get_buffer(m_frame, 32);
    if (ret < 0)
    {
        fprintf(stderr, "Could not allocate frame buffer\n");
        return -1;
    }

    // 分配数据包
    m_packet = av_packet_alloc();
    if (NULL == m_packet)
    {
        fprintf(stderr, "Could not allocate packet\n");
        return -1;
    }

    // 初始化图像转换上下文（BGR -> YUV420P）
    m_swsCtx = sws_getContext(width, height, AV_PIX_FMT_BGR24,
                              width, height, AV_PIX_FMT_YUV420P,
                              SWS_BILINEAR, NULL, NULL, NULL);
    if (NULL == m_swsCtx)
    {
        fprintf(stderr, "Could not create sws context\n");
        return -1;
    }

    m_initialized = true;
    return 0;
}

int CVideoEncoder::EncodeFrame(const cv::Mat &mat)
{
    if (!m_initialized || NULL == m_frame)
    {
        return -1;
    }

    if (mat.cols != m_width || mat.rows != m_height)
    {
        fprintf(stderr, "Frame size mismatch\n");
        return -1;
    }

    // 确保帧可写
    int ret = av_frame_make_writable(m_frame);
    if (ret < 0)
    {
        return -1;
    }

    // 将 BGR 转换为 YUV420P
    uint8_t *srcData[1] = { (uint8_t*)mat.data };
    int srcLinesize[1] = { static_cast<int>(mat.step[0]) };

    sws_scale(m_swsCtx, srcData, srcLinesize, 0, m_height,
              m_frame->data, m_frame->linesize);

    m_frame->pts = m_frameIndex;

    // 每 gop_size 帧设置一个关键帧 (FFmpeg会自动处理)
    if (m_frameIndex % m_codecCtx->gop_size == 0)
    {
        m_frame->pict_type = AV_PICTURE_TYPE_I;
    }
    else
    {
        m_frame->pict_type = AV_PICTURE_TYPE_NONE;
    }

    // 调试信息（前几帧）
    if (m_frameIndex < 3)
    {
        printf("Encoding frame %d: size=%dx%d, pix_fmt=%d, pts=%lld, pict_type=%d\n",
               m_frameIndex, m_frame->width, m_frame->height, m_frame->format, 
               m_frame->pts, m_frame->pict_type);
        printf("  Y linesize=%d, U linesize=%d, V linesize=%d\n",
               m_frame->linesize[0], m_frame->linesize[1], m_frame->linesize[2]);
    }

    m_frameIndex++;

    // 发送帧到编码器
    ret = avcodec_send_frame(m_codecCtx, m_frame);
    if (ret < 0)
    {
        fprintf(stderr, "Error sending frame for encoding\n");
        return -1;
    }

    // 接收编码后的数据包
    while (ret >= 0)
    {
        ret = avcodec_receive_packet(m_codecCtx, m_packet);
        if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF)
        {
            break;
        }
        else if (ret < 0)
        {
            fprintf(stderr, "Error during encoding\n");
            return -1;
        }

        // 设置时间戳
        av_packet_rescale_ts(m_packet, m_codecCtx->time_base, m_videoStream->time_base);
        m_packet->stream_index = m_videoStream->index;

        // 写入数据包
        ret = av_interleaved_write_frame(m_formatCtx, m_packet);
        av_packet_unref(m_packet);
        if (ret < 0)
        {
            fprintf(stderr, "Error writing frame\n");
            return -1;
        }
    }

    return 0;
}

int CVideoEncoder::Finish()
{
    if (!m_initialized)
    {
        return 0;
    }

    // 刷新编码器
    if (NULL != m_codecCtx)
    {
        avcodec_send_frame(m_codecCtx, NULL);

        while (true)
        {
            int ret = avcodec_receive_packet(m_codecCtx, m_packet);
            if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF)
            {
                break;
            }
            else if (ret < 0)
            {
                break;
            }

            av_packet_rescale_ts(m_packet, m_codecCtx->time_base, m_videoStream->time_base);
            m_packet->stream_index = m_videoStream->index;
            av_interleaved_write_frame(m_formatCtx, m_packet);
            av_packet_unref(m_packet);
        }
    }

    // 写入文件尾
    if (NULL != m_formatCtx)
    {
        av_write_trailer(m_formatCtx);
    }

    // 清理资源
    if (NULL != m_swsCtx)
    {
        sws_freeContext(m_swsCtx);
        m_swsCtx = NULL;
    }

    if (NULL != m_frame)
    {
        av_frame_free(&m_frame);
        m_frame = NULL;
    }

    if (NULL != m_packet)
    {
        av_packet_free(&m_packet);
        m_packet = NULL;
    }

    if (NULL != m_codecCtx)
    {
        avcodec_free_context(&m_codecCtx);
        m_codecCtx = NULL;
    }

    if (NULL != m_formatCtx && !(m_formatCtx->oformat->flags & AVFMT_NOFILE))
    {
        avio_closep(&m_formatCtx->pb);
    }

    if (NULL != m_formatCtx)
    {
        avformat_free_context(m_formatCtx);
        m_formatCtx = NULL;
    }

    m_initialized = false;
    return 0;
}

#endif  // USE_OPENCV

