#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <iostream>
#include "func.h"
#include "rmai_info_parse_api.h"
#if defined(USE_OPENCV)
#include "opencv2/opencv.hpp"
#endif

// �ɹ�����0������ʧ�ܷ���-1������ʧ�ܷ�������
int gAnalyseN9Data(char* pBuf, int nLen, VIDEO_DATA* pInfo)
{
	bool bVideo = true;

	if (pBuf[1] == '2')
	{
		pInfo->bIFrame = true;
	}
	else if (pBuf[1] == '5')
	{
		pInfo->bIFrame = true;
		pInfo->nVideoFormat = 1;
	}
	else if (pBuf[1] == '6')
	{
		pInfo->nVideoFormat = 1;
	}
	else if (pBuf[1] == '4')
	{
		bVideo = false;
	}

	RMSTREAM_HEADER* pHead = (RMSTREAM_HEADER*)pBuf;
	int nHeadLen = sizeof(RMSTREAM_HEADER);
	pInfo->pFrame = pBuf + nHeadLen + pHead->lExtendLen;
	pInfo->nTotalLen = nHeadLen + pHead->lExtendLen + pHead->lFrameLen;
	pInfo->nFrameLen = pHead->lFrameLen;
	if (pInfo->nTotalLen > nLen)
		return 2;

	int hdrLen = sizeof(RMS_INFOTYPE);
	int nRemain = pHead->lExtendLen;
	char* pDataEx = pBuf + nHeadLen;
	while (nRemain > hdrLen)
	{
		RMS_INFOTYPE* p = (RMS_INFOTYPE*)pDataEx;
		if (p->lInfoType == 0)
		{
			break;
		}
		if (p->lInfoType == 13)
		{
			if (pInfo->ai_count < AI_BUFC_MAX) pInfo->ai_buf[pInfo->ai_count] = pDataEx;
			pInfo->ai_count++;
		}
		if (p->lInfoType == 1)
		{
			RMFI2_VIDEOINFO* pp = (RMFI2_VIDEOINFO*)pDataEx;
			pInfo->w = pp->lWidth;
			pInfo->h = pp->lHeight;
			pInfo->nFrameRate = pp->lFPS;
		}
		if (p->lInfoType == 2)
		{
			RMFI2_RTCTIME* pp = (RMFI2_RTCTIME*)pDataEx;
			pInfo->time.nYear = pp->stuRtcTime.cYear + 2000;
			pInfo->time.nMonth = pp->stuRtcTime.cMonth;
			pInfo->time.nDay = pp->stuRtcTime.cDay;
			pInfo->time.nHour = pp->stuRtcTime.cHour;
			pInfo->time.nMinute = pp->stuRtcTime.cMinute;
			pInfo->time.nSecond = pp->stuRtcTime.cSecond;
			pInfo->bHaveTime = true;
		}
		if (p->lInfoType == 3)
		{
			memcpy(&pInfo->ullRealPts, p + 1, sizeof(pInfo->ullRealPts));
		}
		if (p->lInfoType == 5)
		{
			RMFI2_N9M_AUDIOINFO* pAudio = (RMFI2_N9M_AUDIOINFO*)pDataEx;
			pInfo->nAudioFormat = pAudio->lPayloadType;
			pInfo->nSampleRate = pAudio->lSampleRate;
		}
		if (p->lInfoType == 6)
		{
			RMFI2_N9M_VIDEOSTATE* pState = (RMFI2_N9M_VIDEOSTATE*)pDataEx;
			pInfo->bEncrypt = pState->lEncryptType;
			pInfo->aes_type = pState->aes_type;
			if (pState->lCameraAngle == 1) pInfo->nRotate = 3;
			else if (pState->lCameraAngle == 2) pInfo->nRotate = 4;
			if (pState->lCameraMirror == 1) pInfo->nRotate = 1;
		}
		if (p->lInfoType == 9)
		{
			RMFI2_ENCODERINFO* ei = (RMFI2_ENCODERINFO*)pDataEx;
			pInfo->nVideoFormat = ei->cEncoderType;
		}
		if (p->lInfoLength == 0 || p->lInfoLength > 100000)
		{
			printf("frame length is incorrect, the length = %d.\n", (int)p->lInfoLength);
			return 1;
		}
		if (p->lInfoLength == 0)
			break;
		nRemain -= p->lInfoLength;
		pDataEx += p->lInfoLength;
	}
	pInfo->bVideo = bVideo;

	if (pInfo->bEncrypt && pInfo->pFrame[0] != 0)
	{
		pInfo->isUnEncryOk = -1;
	}
	else
	{
		pInfo->isUnEncryOk = 0;
	}
	return 0;
}

int gAnalyseData(char* pBuf, int nLen, VIDEO_DATA* pInfo)
{
	if (nLen <= sizeof(RMSTREAM_HEADER))
	{
		return 2;
	}

	memset(pInfo, 0, sizeof(VIDEO_DATA));

	if (pBuf[0] < 0 || pBuf[0] > 32)
		return 1;

	if (pBuf[2] == 'd' && pBuf[3] == 'c')
	{
		if (pBuf[1] > '1' && pBuf[1] < '7')
		{
			return gAnalyseN9Data(pBuf, nLen, pInfo);
		}
		return 1;
	}

	return 1;
}

int gAnalyseData0(char** pBuf, int& nLen, VIDEO_DATA* pInfo, bool isFirst /*= false*/)
{
	int ret = 0;
	if (nLen > 1048576)
		isFirst = true;
	else if (nLen < 36)
		isFirst = false;

	while(1)
	{
		ret = gAnalyseData(*pBuf, nLen, pInfo);
		if (ret == 2)
		{
			if (!isFirst)
				break;
			ret = 1;
		}
		if (ret == 1)
		{
			(*pBuf)++;
			nLen--;
			isFirst = false;
			continue;
		}
		break;
	}

	return ret;
}

void parse_aiInfo_body(void* varsIn, VIDEO_DATA* dataPtr, RMAI_HANDLE handle)
{
	ai_info_outtext_vars* vars = (ai_info_outtext_vars*)varsIn;
	StructSummaryOptions options;

	for (int im = 0; im < dataPtr->ai_count; ++im)
	{
		RMFI2_VIDEOAIINFO* pAiInfo = (RMFI2_VIDEOAIINFO*)dataPtr->ai_buf[im];

		RMAI_Memory memory;
		memset(&memory, 0, sizeof(memory));
		memory.data = (unsigned char*)dataPtr->ai_buf[im] + sizeof(RMFI2_VIDEOAIINFO);
		memory.size = (int)pAiInfo->lAIInfoLen;
		memory.aiPts = pAiInfo->ullPts;

		fprintf(vars->fileAvi, "video PTS: %lld , ai PTS: %lld\n",
		        dataPtr->ullRealPts, pAiInfo->ullPts);

		RMAI_StructOutput out;
		memset(&out, 0, sizeof(out));
		if (RMAIInfo_ParseStruct(handle, memory, &out) != 0)
		{
			++vars->stats.parse_fail_count;
			fprintf(vars->fileAvi, "AI Parse Result: failed\n\n");
			continue;
		}

		++vars->stats.parse_ok_count;

		std::string summary = format_struct_summary(
			&out,
			dataPtr->ullRealPts,
			memory.aiPts,
			vars->frame_index++,
			options,
			&vars->stats);
		if (!summary.empty())
		{
			vars->summary_lines.push_back(summary);
			fprintf(vars->fileAvi, "%s", summary.c_str());
		}
		else
		{
			fprintf(vars->fileAvi, "AI Parse Result: empty\n\n");
		}
	}
}
