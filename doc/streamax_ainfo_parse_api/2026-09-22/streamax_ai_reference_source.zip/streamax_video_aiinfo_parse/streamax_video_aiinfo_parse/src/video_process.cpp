#include <stdio.h>
#include <string.h>
#include <deque>
#include <vector>
#include <climits>
#include <fstream>
#include "func.h"
#include "rmai_info_parse_api.h"
#include "struct_decode.h"
#include "video_decrypt.h"
#include "video_decoder.h"
#include "overlay_manager.h"
#include "overlay_drawer.h"
#include "video_encoder.h"

#if defined(USE_OPENCV)
#include <opencv2/opencv.hpp>
#endif

extern "C"
{
#include <libavcodec/avcodec.h>
}

struct VideoFrameBuffer
{
    cv::Mat mat;
    unsigned long long pts;
    int frameIndex;
};

#if defined(USE_OPENCV)

static void ParseAiOverlaysFromFrame(VIDEO_DATA& data,
                                     RMAI_HANDLE aiHandle,
                                     int frameCount,
                                     COverlayManager& overlayMgr,
                                     std::vector<std::string>& summaryLines,
                                     StructParseStats& stats)
{
    if (data.ai_count <= 0 || aiHandle == RMAI_INVALID_HANDLE)
    {
        return;
    }

    StructSummaryOptions options;
    for (int im = 0; im < data.ai_count; ++im)
    {
        RMFI2_VIDEOAIINFO* pAiInfo = (RMFI2_VIDEOAIINFO*)data.ai_buf[im];

        RMAI_Memory memory;
        memset(&memory, 0, sizeof(memory));
        memory.data = (unsigned char*)data.ai_buf[im] + sizeof(RMFI2_VIDEOAIINFO);
        memory.size = pAiInfo->lAIInfoLen;
        memory.aiPts = pAiInfo->ullPts;

        RMAI_StructOutput out;
        memset(&out, 0, sizeof(out));
        if (RMAIInfo_ParseStruct(aiHandle, memory, &out) != 0)
        {
            ++stats.parse_fail_count;
            continue;
        }

        ++stats.parse_ok_count;

        std::string summary = format_struct_summary(
            &out, data.ullRealPts, memory.aiPts, (uint32_t)frameCount, options, &stats);
        if (!summary.empty())
        {
            summaryLines.push_back(summary);
        }

        std::vector<StructOverlayGroupItem> groups;
        collect_overlay_groups(&out, pAiInfo->ullPts, frameCount, &groups);
        overlayMgr.AddGroups(groups);
    }
}

#endif

/**
 * @brief Parse video and generate MP4 with Struct overlays
 * @param textPath Struct text summary output path (.txt)
 */
extern "C" int ProcessVideoWithOverlay(const char *videoPath, const char *textPath,
                                       const char *outputPath, const char *configPath)
{
#if !defined(USE_OPENCV)
    printf("OpenCV not enabled, cannot process video\n");
    return -1;
#else
    const int PREBUFFER_SIZE = 20;  // Pre-read buffer size (20 frames)

    FILE *fileSrc = fopen(videoPath, "rb");
    if (NULL == fileSrc)
    {
        printf("Failed to open video file: %s\n", videoPath);
        return -1;
    }

    std::vector<std::string> allSummaryLines;
    StructParseStats parseStats;

    // Initialize decryptor
    CVideoDecrypt decryptor;
    if (NULL != configPath && strlen(configPath) > 0)
    {
        if (decryptor.LoadKeyFromConfig(configPath) != 0)
        {
            printf("Warning: Failed to load decrypt key from config, continuing without decryption\n");
        }
    }

    // Initialize video decoder (format determined by first frame)
    CVideoDecoder decoder;
    bool decoderInitialized = false;

    // Initialize video encoder (parameters determined by first frame)
    CVideoEncoder encoder;
    bool encoderInitialized = false;

    // Initialize AI parser (parameters determined by video resolution)
    RMAI_HANDLE aiHandle = RMAI_INVALID_HANDLE;
    bool aiHandleInitialized = false;

    COverlayDrawer drawer;
    COverlayManager overlayMgr;

    std::deque<VideoFrameBuffer> frameBuffer;

    long long ullReaded = 0;
    long long fileLen = 0;
    int bEnd = 0;
    int nBufLen = 2000000;
    char *pBuf = new char[nBufLen];
    int nReadLen = 0;
    int nRemain = 0;
    bool noFoundFrame = true;
    char *pPos = NULL;
    VIDEO_DATA data;
    int nRet = 0;

    // Get file length
    fseek(fileSrc, 0, SEEK_END);
    fileLen = ftell(fileSrc);
    fseek(fileSrc, 0, SEEK_SET);

    int frameCount = 0;
    int videoWidth = 0;
    int videoHeight = 0;
    int videoFps = 25;
    AVCodecID codecId = AV_CODEC_ID_H264;
    bool bGetFirstIFrame = false;  // Whether first I-frame obtained
    int processedFrameCount = 0;  // Processed and output frame count

    printf("Start pre-reading first %d frames and parsing AI overlay info...\n", PREBUFFER_SIZE);

    // ========== Phase 1: Pre-read first 20 frames to buffer ==========
    while (frameBuffer.size() < PREBUFFER_SIZE)
    {
        // Read file chunk
        if (nRemain < 24 || noFoundFrame)
        {
            if (bEnd)
            {
                break;
            }
            nReadLen = (int)fread(pBuf + nRemain, 1, nBufLen - nRemain, fileSrc);

            if (nReadLen < nBufLen - nRemain)
            {
                bEnd = 1;
            }
            if (nReadLen < 1)
            {
                break;
            }
            nRemain = nReadLen + nRemain;
            pPos = pBuf;
        }

        // Analyze data
        nRet = gAnalyseData0(&pPos, nRemain, &data);
        if (nRet == 2)
        {
            memcpy(pBuf, pPos, nRemain);
            noFoundFrame = true;
            continue;
        }

        if (nRet != 0)
        {
            continue;
        }

        noFoundFrame = false;

        // Process video frames only
        if (!data.bVideo)
        {
            pPos += data.nTotalLen;
            nRemain -= data.nTotalLen;
            continue;
        }

        // Wait for first I-frame
        if (!bGetFirstIFrame)
        {
            if (data.bIFrame)
            {
                bGetFirstIFrame = true;
                printf("\n========== First I-Frame Info ==========\n");
                printf("Frame Index: %d\n", frameCount);
                printf("PTS: %llu\n", data.ullRealPts);
                printf("Video Format: %d (%s)\n", data.nVideoFormat, data.nVideoFormat == 1 ? "H.265" : "H.264");
                printf("Resolution: %dx%d\n", data.w, data.h);
                printf("Frame Rate: %d\n", data.nFrameRate);
                printf("Frame Length: %d bytes\n", data.nFrameLen);
                printf("========================================\n\n");
            }
            else
            {
                pPos += data.nTotalLen;
                nRemain -= data.nTotalLen;
                continue;
            }
        }

        // Determine codec type
        if (data.nVideoFormat == 1)
        {
            codecId = AV_CODEC_ID_H265;
        }
        else
        {
            codecId = AV_CODEC_ID_H264;
        }

        // Get video parameters
        if (data.w > 0 && data.h > 0)
        {
            videoWidth = data.w;
            videoHeight = data.h;
        }
        if (data.nFrameRate > 0)
        {
            videoFps = data.nFrameRate;
        }

        // Initialize decoder
        if (!decoderInitialized && videoWidth > 0 && videoHeight > 0)
        {
            if (decoder.InitDecoder(codecId, videoWidth, videoHeight) != 0)
            {
                printf("Failed to initialize decoder\n");
                break;
            }
            decoderInitialized = true;

            // Initialize encoder
            if (encoder.InitEncoder(outputPath, videoWidth, videoHeight, videoFps, codecId) != 0)
            {
                printf("Failed to initialize encoder\n");
                break;
            }
            encoderInitialized = true;

            // Initialize AI parser (using actual video resolution)
            RMAI_ImageSize imageSize;
            imageSize.width = videoWidth;
            imageSize.height = videoHeight;
            aiHandle = RMAIInfo_Parse_Create(imageSize);
            if (aiHandle == RMAI_INVALID_HANDLE)
            {
                printf("Failed to create AI parser with resolution %dx%d\n", videoWidth, videoHeight);
                break;
            }
            aiHandleInitialized = true;
            printf("AI parser initialized successfully, using resolution: %dx%d\n", videoWidth, videoHeight);
        }

        if (!decoderInitialized)
        {
            pPos += data.nTotalLen;
            nRemain -= data.nTotalLen;
            continue;
        }

        // Handle encryption
        unsigned char *frameData = (unsigned char *)data.pFrame;
        int frameLen = data.nFrameLen;
        unsigned char decryptedHeader[64];

        if (data.bEncrypt && data.isUnEncryOk != 0 && frameLen >= 64)
        {
            int aesTypeToUse = (data.aes_type == 2) ? 2 : 1;
            int decryptRet = decryptor.DecryptFrame(frameData, 64, decryptedHeader, aesTypeToUse);
            if (decryptRet > 0)
            {
                memcpy(frameData, decryptedHeader, 64);
            }
            else
            {
                pPos += data.nTotalLen;
                nRemain -= data.nTotalLen;
                continue;
            }
        }

        // Decode video frame
        AVFrame *avFrame = NULL;
        int decodeRet = decoder.DecodeFrame(frameData, frameLen, &avFrame);

        if (decodeRet != 1 || NULL == avFrame)
        {
            pPos += data.nTotalLen;
            nRemain -= data.nTotalLen;
            continue;
        }

        // Convert to OpenCV Mat
        cv::Mat mat;
        if (decoder.AVFrameToMat(avFrame, mat) != 0)
        {
            pPos += data.nTotalLen;
            nRemain -= data.nTotalLen;
            continue;
        }

        if (aiHandleInitialized)
        {
            ParseAiOverlaysFromFrame(data, aiHandle, frameCount, overlayMgr,
                                     allSummaryLines, parseStats);
        }
        else if (frameCount < 5)
        {
            printf("  Frame %d has no AI parser\n", frameCount);
        }

        // Add video frame to buffer
        VideoFrameBuffer bufferItem;
        bufferItem.mat = mat.clone();  // Deep copy
        bufferItem.pts = data.ullRealPts;
        bufferItem.frameIndex = frameCount;
        frameBuffer.push_back(bufferItem);

        if (frameCount < 5 || frameCount % 5 == 0)
        {
            printf("Pre-read frame %d: Video_PTS=%llu, Video_buffer=%zu, AI_groups=%zu\n",
                   frameCount, data.ullRealPts, frameBuffer.size(), overlayMgr.GetAllOverlays().size());
        }

        frameCount++;
        pPos += data.nTotalLen;
        nRemain -= data.nTotalLen;
    }

    printf("Pre-reading completed, Video_buffer=%zu frames, AI_groups=%zu items\n\n",
           frameBuffer.size(), overlayMgr.GetAllOverlays().size());
    printf("========== Start Processing Frames and Matching Overlays ==========\n");

    // ========== Phase 2: Process buffer frames and continue reading new frames ==========
    bool continueReading = !bEnd;

    while (!frameBuffer.empty())
    {
        // Get earliest frame from buffer
        VideoFrameBuffer currentFrame = frameBuffer.front();
        frameBuffer.pop_front();

        const unsigned long long TOLERANCE = 30;
        std::vector<StructOverlayGroupItem> matchedOverlays;
        overlayMgr.FindOverlaysByPts(currentFrame.pts, TOLERANCE, matchedOverlays);

        if (!matchedOverlays.empty())
        {
            if (processedFrameCount < 10)
            {
                printf("\n========== Frame %d Overlay Match (%zu items) ==========\n",
                       currentFrame.frameIndex, matchedOverlays.size());
                printf("Video_PTS: %llu\n", currentFrame.pts);
            }

            float frontVehicleSpeedKmh = 0.f;
            const bool hasFrontVehicleSpeed =
                compute_front_vehicle_speed_kmh(matchedOverlays, &frontVehicleSpeedKmh);

            int successCount = 0;
            int statusLineOffset = 0;
            for (size_t i = 0; i < matchedOverlays.size(); ++i)
            {
                const StructOverlayGroupItem& item = matchedOverlays[i];
                if (NULL == item.buffer.get())
                {
                    continue;
                }

                unsigned long long diff = (item.pts > currentFrame.pts) ?
                    (item.pts - currentFrame.pts) : (currentFrame.pts - item.pts);

                if (processedFrameCount < 10)
                {
                    printf("\n[Overlay %zu/%zu] Type: %s, AI_PTS: %llu, diff: %llu\n",
                           i + 1, matchedOverlays.size(),
                           alg_type_json_name(item.group.alg_type), item.pts, diff);
                }

                const bool showFrontVehicleSpeed =
                    hasFrontVehicleSpeed && (RMAI_ALG_FCW_HMW == item.group.alg_type);
                int drawRet = drawer.DrawOverlayFromGroup(
                    currentFrame.mat, &item.group, item.buffer->data(), item.pts, (int)i,
                    &statusLineOffset, showFrontVehicleSpeed, frontVehicleSpeedKmh);
                if (drawRet == 0)
                {
                    ++successCount;
                    if (processedFrameCount < 10)
                    {
                        printf("+ Overlay drawn successfully\n");
                    }
                }
                else if (processedFrameCount < 10)
                {
                    printf("x Overlay draw failed, return code: %d\n", drawRet);
                }
            }

            if (processedFrameCount < 10)
            {
                printf("\nTotal: Matched %zu, Successfully drawn %d\n",
                       matchedOverlays.size(), successCount);
                printf("====================================================\n\n");
            }
        }
        else if (processedFrameCount < 10)
        {
            printf("\n========== Frame %d No Overlay Match ==========\n", currentFrame.frameIndex);
            printf("Video_PTS: %llu\n", currentFrame.pts);
            printf("AI groups size: %zu\n", overlayMgr.GetAllOverlays().size());
            printf("===============================================\n\n");
        }

        // Encode and write to MP4
        if (encoder.EncodeFrame(currentFrame.mat) != 0)
        {
            printf("Failed to encode frame %d\n", currentFrame.frameIndex);
        }

        processedFrameCount++;
        if (processedFrameCount % 100 == 0)
        {
            printf("Processed %d frames, Video_buffer=%zu, AI_groups=%zu\n",
                   processedFrameCount, frameBuffer.size(), overlayMgr.GetAllOverlays().size());
        }

        overlayMgr.RemoveBeforePts(currentFrame.pts);

        // Continue reading new frames to refill buffer (maintain 20 frames)
        if (continueReading && frameBuffer.size() < PREBUFFER_SIZE)
        {
            bool foundNewFrame = false;

            while (!foundNewFrame && continueReading)
            {
                // Read file chunk
                if (nRemain < 24 || noFoundFrame)
                {
                    if (bEnd)
                    {
                        continueReading = false;
                        break;
                    }
                    nReadLen = (int)fread(pBuf + nRemain, 1, nBufLen - nRemain, fileSrc);

                    if (nReadLen < nBufLen - nRemain)
                    {
                        bEnd = 1;
                    }
                    if (nReadLen < 1)
                    {
                        continueReading = false;
                        break;
                    }
                    nRemain = nReadLen + nRemain;
                    pPos = pBuf;
                }

                // Analyze data
                nRet = gAnalyseData0(&pPos, nRemain, &data);
                if (nRet == 2)
                {
                    memcpy(pBuf, pPos, nRemain);
                    noFoundFrame = true;
                    continue;
                }

                if (nRet != 0)
                {
                    continue;
                }

                noFoundFrame = false;

                // Process video frames only
                if (!data.bVideo)
                {
                    pPos += data.nTotalLen;
                    nRemain -= data.nTotalLen;
                    continue;
                }

                // Handle encryption
                unsigned char *frameData = (unsigned char *)data.pFrame;
                int frameLen = data.nFrameLen;
                unsigned char decryptedHeader[64];

                if (data.bEncrypt && data.isUnEncryOk != 0 && frameLen >= 64)
                {
                    int aesTypeToUse = (data.aes_type == 2) ? 2 : 1;
                    int decryptRet = decryptor.DecryptFrame(frameData, 64, decryptedHeader, aesTypeToUse);
                    if (decryptRet > 0)
                    {
                        memcpy(frameData, decryptedHeader, 64);
                    }
                    else
                    {
                        pPos += data.nTotalLen;
                        nRemain -= data.nTotalLen;
                        continue;
                    }
                }

                // Decode video frame
                AVFrame *avFrame = NULL;
                int decodeRet = decoder.DecodeFrame(frameData, frameLen, &avFrame);

                if (decodeRet != 1 || NULL == avFrame)
                {
                    pPos += data.nTotalLen;
                    nRemain -= data.nTotalLen;
                    continue;
                }

                // Convert to OpenCV Mat
                cv::Mat mat;
                if (decoder.AVFrameToMat(avFrame, mat) != 0)
                {
                    pPos += data.nTotalLen;
                    nRemain -= data.nTotalLen;
                    continue;
                }

                if (aiHandleInitialized)
                {
                    ParseAiOverlaysFromFrame(data, aiHandle, frameCount, overlayMgr,
                                             allSummaryLines, parseStats);
                }

                // Add new frame to buffer
                VideoFrameBuffer bufferItem;
                bufferItem.mat = mat.clone();
                bufferItem.pts = data.ullRealPts;
                bufferItem.frameIndex = frameCount;
                frameBuffer.push_back(bufferItem);

                frameCount++;
                foundNewFrame = true;

        pPos += data.nTotalLen;
        nRemain -= data.nTotalLen;
            }
        }
    }

    // Finish encoding
    if (encoderInitialized)
    {
        encoder.Finish();
    }

    print_struct_stats(parseStats);

    if (!allSummaryLines.empty() && NULL != textPath && strlen(textPath) > 0)
    {
        printf("\n========== Saving Struct Text Summary ==========\n");
        printf("Text file: %s\n", textPath);
        printf("Total summary blocks: %zu\n", allSummaryLines.size());

        std::ofstream textFile(textPath);
        if (textFile.is_open())
        {
            for (size_t i = 0; i < allSummaryLines.size(); ++i)
            {
                textFile << allSummaryLines[i];
            }
            textFile.close();
            printf("+ Text summary saved successfully\n");
        }
        else
        {
            printf("x Unable to open text file for writing\n");
        }
        printf("================================================\n");
    }

    // Clean up resources
    if (aiHandleInitialized)
    {
        RMAIInfo_Parse_Destroy(aiHandle);
    }
    fclose(fileSrc);
    fileSrc = NULL;
    delete[] pBuf;
    pBuf = NULL;

    printf("\n========== Processing Completed ==========\n");
    printf("Total parsed frames: %d\n", frameCount);
    printf("Total output frames: %d\n", processedFrameCount);
    return 0;
#endif
}

