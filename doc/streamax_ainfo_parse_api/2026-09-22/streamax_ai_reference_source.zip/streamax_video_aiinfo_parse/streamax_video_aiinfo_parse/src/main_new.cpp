// 注意：此文件仅用于独立编译测试
// 正常编译时，ProcessVideoWithOverlay 函数在 video_process.cpp 中定义
// main 函数在 main.cpp 中定义

#ifdef STANDALONE_MAIN
#include <stdio.h>

// 声明函数（实际实现在 video_process.cpp 中）
extern "C" int ProcessVideoWithOverlay(const char *videoPath, const char *textPath,
                                       const char *outputPath, const char *configPath);

int main(int argc, char *argv[])
{
    if (argc < 3)
    {
        printf("Usage: %s <video_file> <text_file> [output_file] [config_file]\n", argv[0]);
        printf("  video_file: Input 264/265 video file\n");
        printf("  text_file:  Struct text summary file\n");
        printf("  output_file: Output MP4 file (default: output.mp4)\n");
        printf("  config_file: Config file with decrypt key (optional)\n");
        return -1;
    }

    const char *videoPath = argv[1];
    const char *textPath = argv[2];
    const char *outputPath = (argc >= 4) ? argv[3] : "output.mp4";
    const char *configPath = (argc >= 5) ? argv[4] : NULL;

    printf("Processing video: %s\n", videoPath);
    printf("Struct summary: %s\n", textPath);
    printf("Output file: %s\n", outputPath);
    if (NULL != configPath)
    {
        printf("Config file: %s\n", configPath);
    }

    int ret = ProcessVideoWithOverlay(videoPath, textPath, outputPath, configPath);
    if (ret != 0)
    {
        printf("Processing failed\n");
        return 1;
    }

    printf("Processing completed successfully\n");
    return 0;
}
#endif
