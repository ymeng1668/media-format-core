#include "overlay_manager.h"
#include "struct_decode.h"
#include <algorithm>
#include <climits>

COverlayManager::COverlayManager()
{
}

COverlayManager::~COverlayManager()
{
    Clear();
}

void COverlayManager::AddGroup(const StructOverlayGroupItem& item)
{
    m_overlays.push_back(item);
}

void COverlayManager::AddGroups(const std::vector<StructOverlayGroupItem>& items)
{
    m_overlays.insert(m_overlays.end(), items.begin(), items.end());
}

void COverlayManager::FindOverlaysByPts(uint64_t pts,
                                        uint64_t tolerance,
                                        std::vector<StructOverlayGroupItem>& matched) const
{
    matched.clear();

    for (size_t i = 0; i < m_overlays.size(); ++i)
    {
        const StructOverlayGroupItem& item = m_overlays[i];
        if (NULL == item.buffer.get())
        {
            continue;
        }

        uint64_t diff = (item.pts > pts) ? (item.pts - pts) : (pts - item.pts);
        if (diff <= tolerance &&
            struct_group_has_content(&item.group, item.buffer->data()))
        {
            matched.push_back(item);
        }
    }
}

void COverlayManager::RemoveBeforePts(uint64_t threshold)
{
    size_t write_index = 0;
    for (size_t i = 0; i < m_overlays.size(); ++i)
    {
        if (m_overlays[i].pts + 10000 >= threshold)
        {
            if (write_index != i)
            {
                m_overlays[write_index] = m_overlays[i];
            }
            ++write_index;
        }
    }
    m_overlays.resize(write_index);
}

void COverlayManager::Clear()
{
    m_overlays.clear();
}
