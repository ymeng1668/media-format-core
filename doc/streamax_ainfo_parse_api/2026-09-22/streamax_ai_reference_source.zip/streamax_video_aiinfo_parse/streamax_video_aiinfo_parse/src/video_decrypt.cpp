#include "video_decrypt.h"
#include <fstream>
#include <cstring>
#include <iostream>
#include <cstdlib>

CVideoDecrypt::CVideoDecrypt()
{
    memset(m_key, 0, sizeof(m_key));
    m_keyLen = 0;
    m_keySet = false;
}

CVideoDecrypt::~CVideoDecrypt()
{
}

int CVideoDecrypt::LoadKeyFromConfig(const std::string &configPath)
{
    std::ifstream file(configPath);
    if (!file.is_open())
    {
        std::cerr << "Failed to open config file: " << configPath << std::endl;
        return -1;
    }

    std::string line;
    std::string keyStr;

    while (std::getline(file, line))
    {
        // 查找 key= 或 decrypt_key= 配置项
        size_t pos = line.find("key=");
        if (pos == std::string::npos)
        {
            pos = line.find("decrypt_key=");
            if (pos != std::string::npos)
            {
                pos += 12;  // "decrypt_key=" 的长度
            }
        }
        else
        {
            pos += 4;  // "key=" 的长度
        }

        if (pos != std::string::npos)
        {
            keyStr = line.substr(pos);
            // 去除前后空格
            while (!keyStr.empty() && (keyStr[0] == ' ' || keyStr[0] == '\t'))
            {
                keyStr.erase(0, 1);
            }
            while (!keyStr.empty() && (keyStr.back() == ' ' || keyStr.back() == '\t' || keyStr.back() == '\r'))
            {
                keyStr.pop_back();
            }
            break;
        }
    }

    file.close();

    if (keyStr.empty())
    {
        std::cerr << "No key found in config file" << std::endl;
        return -1;
    }

    // 判断是十六进制字符串还是直接字符串
    if (keyStr.length() >= 2 && keyStr.substr(0, 2) == "0x")
    {
        // 十六进制格式
        keyStr = keyStr.substr(2);
        int hexLen = keyStr.length() / 2;
        if (hexLen > 32)
        {
            hexLen = 32;
        }

        for (int i = 0; i < hexLen && i * 2 < (int)keyStr.length(); ++i)
        {
            std::string byteStr = keyStr.substr(i * 2, 2);
            m_key[i] = (unsigned char)strtoul(byteStr.c_str(), NULL, 16);
        }
        m_keyLen = hexLen;
    }
    else
    {
        // 直接字符串格式
        int len = keyStr.length();
        if (len > 32)
        {
            len = 32;
        }
        memcpy(m_key, keyStr.c_str(), len);
        m_keyLen = len;
    }

    m_keySet = true;
    return 0;
}

int CVideoDecrypt::SetKey(const unsigned char *key, int keyLen)
{
    if (NULL == key || keyLen <= 0 || keyLen > 32)
    {
        return -1;
    }

    memcpy(m_key, key, keyLen);
    m_keyLen = keyLen;
    m_keySet = true;
    return 0;
}

int CVideoDecrypt::DecryptFrame(const unsigned char *encryptedData, int dataLen, 
                                 unsigned char *decryptedData, int aesType)
{
    if (NULL == encryptedData || NULL == decryptedData || dataLen <= 0)
    {
        return -1;
    }

    if (!m_keySet)
    {
        std::cerr << "Key not set" << std::endl;
        return -1;
    }

    try
    {
        int keySize = 16;  // AES128
        if (aesType == 1)
        {
            keySize = 24;  // AES192
        }
        else if (aesType == 2)
        {
            keySize = 32;  // AES256
        }

        if (m_keyLen < keySize)
        {
            std::cerr << "Key length too short for AES type: " << aesType << std::endl;
            return -1;
        }

        // 使用 ECB 模式解密（根据实际需求可能需要 CBC 或其他模式）
        // 注意：这里使用 ECB 模式，如果实际使用的是 CBC 模式，需要提供 IV
        CryptoPP::ECB_Mode<CryptoPP::AES>::Decryption decryptor;
        decryptor.SetKey(m_key, keySize);

        // 使用 StreamTransformationFilter::NO_PADDING 避免自动 padding 处理
        // 视频流加密通常是固定块大小（64字节），不需要 padding
        CryptoPP::StringSource ss(
            encryptedData, 
            dataLen, 
            true,
            new CryptoPP::StreamTransformationFilter(
                decryptor,
                new CryptoPP::ArraySink(decryptedData, dataLen),
                CryptoPP::StreamTransformationFilter::NO_PADDING  // 不处理 padding
            )
        );

        // 返回实际解密的数据长度（固定64字节）
        return dataLen;
    }
    catch (const CryptoPP::Exception &e)
    {
        std::cerr << "Decryption error: " << e.what() << std::endl;
        return -1;
    }
}

