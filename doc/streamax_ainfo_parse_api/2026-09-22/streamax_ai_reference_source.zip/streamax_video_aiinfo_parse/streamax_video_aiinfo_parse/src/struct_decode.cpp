#include "struct_decode.h"

#include <cstdio>
#include <sstream>

namespace {

bool validate_output_header(const RMAI_StructOutput* out, const RMAI_AlgOutputHeader** hdr_out)
{
    if (NULL == out || NULL == out->buffer || out->buffer_size <= 0)
    {
        return false;
    }

    if ((int)sizeof(RMAI_AlgOutputHeader) > out->buffer_size)
    {
        return false;
    }

    const RMAI_AlgOutputHeader* hdr = (const RMAI_AlgOutputHeader*)out->buffer;
    if (hdr->magic != RMAI_STRUCT_MAGIC || hdr->version != RMAI_STRUCT_VERSION)
    {
        return false;
    }

    if ((int)hdr->total_size > out->buffer_size)
    {
        return false;
    }

    if (hdr->groups_offset + hdr->group_count * sizeof(RMAI_AlgGroupHeader) > hdr->total_size)
    {
        return false;
    }

    *hdr_out = hdr;
    return true;
}

void append_alarm_stats(const RMAI_AlgGroupDataBlockHeader* block,
                        const uint8_t* payload_base,
                        StructParseStats* stats)
{
    if (NULL == block || block->count == 0)
    {
        return;
    }

    stats->total_alarms += block->count;
    (void)payload_base;
}

void collect_group_stats(const uint8_t* buffer,
                         const RMAI_AlgGroupHeader* group,
                         StructParseStats* stats)
{
    if (group->payload_offset + group->payload_size > ((const RMAI_AlgOutputHeader*)buffer)->total_size)
    {
        return;
    }

    const uint8_t* payload_base = buffer + group->payload_offset;
    if (group->payload_size < sizeof(RMAI_AlgGroupPayloadHeader))
    {
        return;
    }

    const RMAI_AlgGroupPayloadHeader* ph = (const RMAI_AlgGroupPayloadHeader*)payload_base;
    const RMAI_AlgGroupDataBlockHeader* blocks =
        (const RMAI_AlgGroupDataBlockHeader*)(payload_base + sizeof(RMAI_AlgGroupPayloadHeader));

    for (int i = 0; i < ph->data_block_count; ++i)
    {
        const RMAI_AlgGroupDataBlockHeader* block = &blocks[i];
        if (block->data_offset + block->data_size > group->payload_size)
        {
            continue;
        }

        if (block->block_type == RMAI_ALG_ALARMS)
        {
            append_alarm_stats(block, payload_base, stats);
        }
    }
}

bool block_has_drawable_content(const RMAI_AlgGroupDataBlockHeader* block)
{
    if (NULL == block || 0 == block->count)
    {
        return false;
    }

    switch (block->block_type)
    {
    case RMAI_ADAS_VEHICLES:
    case RMAI_ADAS_PEDESTRIANS:
    case RMAI_ADAS_LEFT_LANE_POINTS:
    case RMAI_ADAS_RIGHT_LANE_POINTS:
    case RMAI_ADAS_ROLLING_STOP_COORDS:
    case RMAI_ADAS_SPEED_LIMIT_SIGN_COORDS:
    case RMAI_ADAS_DETECTION_AREA:
    case RMAI_ALG_ALARMS:
    case RMAI_ADAS_STATUS:
    case RMAI_DSC_HEAD_POSE:
    case RMAI_DSC_FACE_RECTS:
    case RMAI_DSC_FACE_KEY_POINTS:
    case RMAI_DSC_PHONE_RECTS:
    case RMAI_DSC_SEATBELT_CONTOURS:
    case RMAI_DSC_VECHILE_SPEED:
    case RMAI_DSC_DETECTION_AREA:
        return true;
    default:
        return false;
    }
}

void append_vehicle_lines(std::ostringstream& oss,
                          const RMAI_AlgGroupDataBlockHeader* block,
                          const uint8_t* payload_base)
{
    if (block->count == 0 || block->elem_size != sizeof(RMAI_Vehicle))
    {
        return;
    }

    const RMAI_Vehicle* vehicles =
        (const RMAI_Vehicle*)(payload_base + block->data_offset);
    for (uint32_t i = 0; i < block->count; ++i)
    {
        oss << "    [" << i << "] rect=(" << vehicles[i].x << "," << vehicles[i].y
            << "," << vehicles[i].width << "," << vehicles[i].height << ")";
        if (vehicles[i].flags & 0x01)
        {
            oss << " distance=" << vehicles[i].distance << "m";
        }
        else
        {
            oss << " distance=--";
        }
        oss << " target=" << (int)vehicles[i].is_target << "\n";
    }
}

void append_pedestrian_lines(std::ostringstream& oss,
                             const RMAI_AlgGroupDataBlockHeader* block,
                             const uint8_t* payload_base)
{
    if (block->count == 0 || block->elem_size != sizeof(RMAI_Pedestrian))
    {
        return;
    }

    const RMAI_Pedestrian* pedestrians =
        (const RMAI_Pedestrian*)(payload_base + block->data_offset);
    for (uint32_t i = 0; i < block->count; ++i)
    {
        oss << "    [" << i << "] rect=(" << pedestrians[i].x << "," << pedestrians[i].y
            << "," << pedestrians[i].width << "," << pedestrians[i].height << ")";
        if (pedestrians[i].flags & 0x01)
        {
            oss << " distance=" << pedestrians[i].distance << "m";
        }
        else
        {
            oss << " distance=--";
        }
        oss << " target=" << (int)pedestrians[i].is_target << "\n";
    }
}

void append_dsc_speed_lines(std::ostringstream& oss,
                            const RMAI_AlgGroupDataBlockHeader* block,
                            const uint8_t* payload_base)
{
    if (block->count != 1 || block->elem_size != sizeof(RMAI_VechileSpeed))
    {
        return;
    }

    const RMAI_VechileSpeed* speed_item =
        (const RMAI_VechileSpeed*)(payload_base + block->data_offset);
    oss << "    speed=" << speed_item->speed << " km/h\n";
}

void append_alarm_lines(std::ostringstream& oss,
                        const RMAI_AlgGroupDataBlockHeader* block,
                        const uint8_t* payload_base)
{
    if (block->count == 0 || block->elem_size != sizeof(RMAI_AlarmItem))
    {
        return;
    }

    const RMAI_AlarmItem* alarms =
        (const RMAI_AlarmItem*)(payload_base + block->data_offset);
    for (uint32_t i = 0; i < block->count; ++i)
    {
        oss << "    [" << i << "] alarm_type=" << alarms[i].alarm_type
            << " (" << alarm_type_name(alarms[i].alarm_type) << ")\n";
    }
}

void append_status_lines(std::ostringstream& oss,
                         const RMAI_AlgGroupDataBlockHeader* block,
                         const uint8_t* payload_base)
{
    if (block->count == 0 || block->elem_size != sizeof(RMAI_StatusItem))
    {
        return;
    }

    const RMAI_StatusItem* status_items =
        (const RMAI_StatusItem*)(payload_base + block->data_offset);
    for (uint32_t i = 0; i < block->count; ++i)
    {
        oss << "    [" << i << "] status_type=" << status_items[i].status_type
            << " (" << status_type_name(status_items[i].status_type) << ")"
            << " text=\"" << status_items[i].text << "\"\n";
    }
}

} // namespace

const RMAI_AlgGroupDataBlockHeader* find_data_block(
    const uint8_t* payload_base,
    const RMAI_AlgGroupPayloadHeader* ph,
    uint32_t want_block_type)
{
    if (NULL == payload_base || NULL == ph)
    {
        return NULL;
    }

    const RMAI_AlgGroupDataBlockHeader* blocks =
        (const RMAI_AlgGroupDataBlockHeader*)(payload_base + sizeof(RMAI_AlgGroupPayloadHeader));

    for (int i = 0; i < ph->data_block_count; ++i)
    {
        if (blocks[i].block_type == want_block_type)
        {
            return &blocks[i];
        }
    }

    return NULL;
}

bool struct_group_has_content(const RMAI_AlgGroupHeader* group, const uint8_t* buffer)
{
    if (NULL == group || NULL == buffer)
    {
        return false;
    }

    const RMAI_AlgOutputHeader* hdr = (const RMAI_AlgOutputHeader*)buffer;
    if (group->payload_offset + group->payload_size > hdr->total_size)
    {
        return false;
    }

    if (group->payload_size < sizeof(RMAI_AlgGroupPayloadHeader))
    {
        return false;
    }

    const uint8_t* payload_base = buffer + group->payload_offset;
    const RMAI_AlgGroupPayloadHeader* ph = (const RMAI_AlgGroupPayloadHeader*)payload_base;
    const RMAI_AlgGroupDataBlockHeader* blocks =
        (const RMAI_AlgGroupDataBlockHeader*)(payload_base + sizeof(RMAI_AlgGroupPayloadHeader));

    for (int i = 0; i < ph->data_block_count; ++i)
    {
        const RMAI_AlgGroupDataBlockHeader* block = &blocks[i];
        if (block->data_offset + block->data_size > group->payload_size)
        {
            continue;
        }

        if (block_has_drawable_content(block))
        {
            return true;
        }
    }

    return false;
}

void collect_overlay_groups(
    const RMAI_StructOutput* out,
    uint64_t ai_pts,
    int frame_index,
    std::vector<StructOverlayGroupItem>* items)
{
    if (NULL == out || NULL == items)
    {
        return;
    }

    const RMAI_AlgOutputHeader* hdr = NULL;
    if (!validate_output_header(out, &hdr) || 0 == hdr->group_count)
    {
        return;
    }

    std::shared_ptr<std::vector<uint8_t> > shared_buffer(new std::vector<uint8_t>());
    shared_buffer->assign(out->buffer, out->buffer + hdr->total_size);

    const RMAI_AlgGroupHeader* groups =
        (const RMAI_AlgGroupHeader*)(shared_buffer->data() + hdr->groups_offset);

    for (uint16_t gi = 0; gi < hdr->group_count; ++gi)
    {
        StructOverlayGroupItem item;
        item.buffer = shared_buffer;
        item.group = groups[gi];
        item.pts = ai_pts;
        item.frameIndex = frame_index;
        items->push_back(item);
    }
}

void update_struct_stats(const RMAI_StructOutput* out, StructParseStats* stats)
{
    const RMAI_AlgOutputHeader* hdr = NULL;
    if (!validate_output_header(out, &hdr))
    {
        return;
    }

    if (0 == hdr->group_count)
    {
        ++stats->empty_result_count;
        return;
    }

    stats->total_groups += hdr->group_count;

    const RMAI_AlgGroupHeader* groups =
        (const RMAI_AlgGroupHeader*)(out->buffer + hdr->groups_offset);
    for (uint16_t gi = 0; gi < hdr->group_count; ++gi)
    {
        collect_group_stats(out->buffer, &groups[gi], stats);
    }
}

std::string format_struct_summary(
    const RMAI_StructOutput* out,
    uint64_t video_pts,
    uint64_t ai_pts,
    uint32_t frame_index,
    const StructSummaryOptions& opt,
    StructParseStats* stats)
{
    const RMAI_AlgOutputHeader* hdr = NULL;
    if (!validate_output_header(out, &hdr))
    {
        return std::string();
    }

    if (0 == hdr->group_count)
    {
        ++stats->empty_result_count;
        std::ostringstream oss;
        oss << "=== Frame #" << frame_index << " video_pts=" << video_pts
            << " ai_pts=" << ai_pts << " (empty) ===\n";
        return oss.str();
    }

    stats->total_groups += hdr->group_count;

    std::ostringstream oss;
    oss << "=== Frame #" << frame_index << " video_pts=" << video_pts
        << " ai_pts=" << ai_pts << " ===\n";
    oss << "group_count=" << hdr->group_count << " total_size=" << hdr->total_size << "\n";

    const RMAI_AlgGroupHeader* groups =
        (const RMAI_AlgGroupHeader*)(out->buffer + hdr->groups_offset);

    for (uint16_t gi = 0; gi < hdr->group_count; ++gi)
    {
        const RMAI_AlgGroupHeader* group = &groups[gi];
        oss << "\n--- Group[" << gi << "] alg_type=" << group->alg_type
            << "(" << alg_type_json_name(group->alg_type) << ")"
            << " group_id=" << group->group_id
            << " category=" << category_name(group->category) << " ---\n";

        if (group->payload_offset + group->payload_size > hdr->total_size)
        {
            oss << "  (invalid payload range)\n";
            continue;
        }

        const uint8_t* payload_base = out->buffer + group->payload_offset;
        if (group->payload_size < sizeof(RMAI_AlgGroupPayloadHeader))
        {
            oss << "  (payload too small)\n";
            continue;
        }

        const RMAI_AlgGroupPayloadHeader* ph = (const RMAI_AlgGroupPayloadHeader*)payload_base;
        const RMAI_AlgGroupDataBlockHeader* blocks =
            (const RMAI_AlgGroupDataBlockHeader*)(payload_base + sizeof(RMAI_AlgGroupPayloadHeader));

        for (int bi = 0; bi < ph->data_block_count; ++bi)
        {
            const RMAI_AlgGroupDataBlockHeader* block = &blocks[bi];
            if (block->data_offset + block->data_size > group->payload_size)
            {
                continue;
            }

            oss << "  DataBlock " << block_type_name(block->block_type)
                << "(" << block->block_type << "): count=" << block->count
                << " elem_size=" << block->elem_size << "\n";

            if (block->block_type == RMAI_ADAS_VEHICLES && opt.include_vehicle_detail)
            {
                append_vehicle_lines(oss, block, payload_base);
            }
            else if (block->block_type == RMAI_ADAS_PEDESTRIANS && opt.include_pedestrian_detail)
            {
                append_pedestrian_lines(oss, block, payload_base);
            }
            else if (block->block_type == RMAI_ALG_ALARMS && opt.include_alarm_detail)
            {
                append_alarm_lines(oss, block, payload_base);
                stats->total_alarms += block->count;
            }
            else if (block->block_type == RMAI_ADAS_STATUS && opt.include_status_detail)
            {
                append_status_lines(oss, block, payload_base);
            }
            else if (block->block_type == RMAI_DSC_VECHILE_SPEED && opt.include_status_detail)
            {
                append_dsc_speed_lines(oss, block, payload_base);
            }
            else if (block->block_type == RMAI_ALG_ALARMS)
            {
                stats->total_alarms += block->count;
            }
        }
    }

    oss << "\n";
    return oss.str();
}

const char* block_type_name(uint32_t block_type)
{
    switch (block_type)
    {
    case RMAI_ADAS_VEHICLES: return "VEHICLES";
    case RMAI_ADAS_DETECTION_AREA: return "DETECTION_AREA";
    case RMAI_ALG_ALARMS: return "ALARMS";
    case RMAI_ADAS_STATUS: return "STATUS";
    case RMAI_ADAS_LEFT_LANE_POINTS: return "LEFT_LANE_POINTS";
    case RMAI_ADAS_RIGHT_LANE_POINTS: return "RIGHT_LANE_POINTS";
    case RMAI_ADAS_PEDESTRIANS: return "PEDESTRIANS";
    case RMAI_ADAS_ROLLING_STOP_COORDS: return "ROLLING_STOP_COORDS";
    case RMAI_ADAS_SPEED_LIMIT_SIGN_COORDS: return "SPEED_LIMIT_SIGN_COORDS";
    case RMAI_DSC_HEAD_POSE: return "HEAD_POSE";
    case RMAI_DSC_FACE_RECTS: return "FACE_RECTS";
    case RMAI_DSC_FACE_KEY_POINTS: return "FACE_KEY_POINTS";
    case RMAI_DSC_PHONE_RECTS: return "PHONE_RECTS";
    case RMAI_DSC_SEATBELT_CONTOURS: return "SEATBELT_CONTOURS";
    case RMAI_DSC_VECHILE_SPEED: return "DSC_VECHILE_SPEED";
    case RMAI_DSC_DETECTION_AREA: return "DSC_DETECTION_AREA";
    default: return "UNKNOWN";
    }
}

const char* alarm_type_name(uint32_t alarm_type)
{
    switch (alarm_type)
    {
    case RMAI_ALARM_ADAS_FCW_COLLISION: return "ADAS_FCW_COLLISION";
    case RMAI_ALARM_ADAS_HMW_CAR_DISTANCE_CLOSE: return "ADAS_HMW_CAR_DISTANCE_CLOSE";
    case RMAI_ALARM_ADAS_LDW_LANE_DEPARTURE_LEFT: return "ADAS_LDW_LANE_DEPARTURE_LEFT";
    case RMAI_ALARM_ADAS_LDW_LANE_DEPARTURE_RIGHT: return "ADAS_LDW_LANE_DEPARTURE_RIGHT";
    case RMAI_ALARM_ADAS_PCW_PEDESTRIAN_COLLISION: return "ADAS_PCW_PEDESTRIAN_COLLISION";
    case RMAI_ALARM_TSR_STOP_ALARM: return "TSR_STOP_ALARM";
    case RMAI_ALARM_TSR_SPEED_LIMIT_ALARM: return "TSR_SPEED_LIMIT_ALARM";
    case RMAI_ALARM_NO_DRIVER: return "NO_DRIVER";
    case RMAI_ALARM_FATIGUE: return "FATIGUE";
    case RMAI_ALARM_DISTRACTED: return "DISTRACTED";
    case RMAI_ALARM_PHONE_DETECTED: return "PHONE_DETECTED";
    case RMAI_ALARM_NO_BELT: return "NO_BELT";
    case RMAI_ALARM_BLOCK_GLASS: return "BLOCK_GLASS";
    default: return "UNKNOWN";
    }
}

const char* status_type_name(uint32_t status_type)
{
    switch (status_type)
    {
    case RMAI_STATUS_ADAS_FCW_TTC: return "ADAS_FCW_TTC";
    case RMAI_STATUS_ADAS_HMW_TTC: return "ADAS_HMW_TTC";
    case RMAI_STATUS_ADAS_CAR_SPEED: return "ADAS_CAR_SPEED";
    case RMAI_STATUS_ADAS_CAR_RELATIVE_SPEED: return "ADAS_CAR_RELATIVE_SPEED";
    default: return "UNKNOWN";
    }
}

const char* alg_type_name(uint32_t alg_type)
{
    switch (alg_type)
    {
    case RMAI_ALG_FCW_HMW: return "FCW/HMW";
    case RMAI_ALG_LDW: return "LDW";
    case RMAI_ALG_PCW: return "PCW";
    case RMAI_ALG_DSC_FACE_DETECT: return "DSC_FACE_DETECT";
    case RMAI_ALG_DSC_YAWN_POSE: return "DSC_YAWN_POSE";
    case RMAI_ALG_DSC_EYE_STATUS: return "DSC_EYE_STATUS";
    case RMAI_ALG_DSC_CALL: return "DSC_CALL";
    case RMAI_ALG_DSC_BELT: return "DSC_BELT";
    case RMAI_ALG_TSR: return "TSR";
    default: return "UNKNOWN";
    }
}

const char* alg_type_json_name(uint32_t alg_type)
{
    switch (alg_type)
    {
    case RMAI_ALG_FCW_HMW: return "fcw_hmw";
    case RMAI_ALG_LDW: return "ldw";
    case RMAI_ALG_PCW: return "pcw";
    case RMAI_ALG_DSC_FACE_DETECT: return "dsc_face_detect";
    case RMAI_ALG_DSC_FACE_ALIGN: return "dsc_face_align";
    case RMAI_ALG_DSC_YAWN_POSE: return "dsc_yawn_and_pose";
    case RMAI_ALG_DSC_EYE_STATUS: return "dsc_eys_status";
    case RMAI_ALG_DSC_CALL: return "dsc_call";
    case RMAI_ALG_DSC_BELT: return "dsc_belt";
    case RMAI_ALG_TSR: return "tsr";
    default: return "unknown";
    }
}

const char* category_name(uint16_t category)
{
    switch (category)
    {
    case RMAI_CATEGORY_ADAS: return "ADAS";
    case RMAI_CATEGORY_DSC: return "DSC";
    default: return "UNKNOWN";
    }
}

void print_struct_stats(const StructParseStats& stats)
{
    printf("Struct parse stats: ok=%llu fail=%llu empty=%llu groups=%llu alarms=%llu\n",
           (unsigned long long)stats.parse_ok_count,
           (unsigned long long)stats.parse_fail_count,
           (unsigned long long)stats.empty_result_count,
           (unsigned long long)stats.total_groups,
           (unsigned long long)stats.total_alarms);
}

bool parse_status_speed_kmh(const char* text, float* out_kmh)
{
    if (NULL == text || NULL == out_kmh)
    {
        return false;
    }

    float value = 0.f;
    if (1 != sscanf(text, "%f", &value))
    {
        return false;
    }

    *out_kmh = value;
    return true;
}

namespace {

void collect_status_speeds_from_overlay(
    const StructOverlayGroupItem& item,
    bool* car_speed_found,
    float* car_speed_kmh,
    bool* relative_speed_found,
    float* relative_speed_kmh)
{
    if (NULL == item.buffer.get() || item.buffer->empty())
    {
        return;
    }

    const uint8_t* buffer = item.buffer->data();
    const RMAI_AlgGroupHeader* group = &item.group;
    if (group->payload_size < (uint32_t)sizeof(RMAI_AlgGroupPayloadHeader))
    {
        return;
    }

    const size_t payload_end = (size_t)group->payload_offset + group->payload_size;
    if (payload_end > item.buffer->size())
    {
        return;
    }

    const uint8_t* payload_base = buffer + group->payload_offset;
    const RMAI_AlgGroupPayloadHeader* ph =
        (const RMAI_AlgGroupPayloadHeader*)payload_base;
    const RMAI_AlgGroupDataBlockHeader* status_block =
        find_data_block(payload_base, ph, RMAI_ADAS_STATUS);
    if (NULL == status_block || status_block->count == 0 ||
        status_block->elem_size != sizeof(RMAI_StatusItem))
    {
        return;
    }

    const RMAI_StatusItem* status_list =
        (const RMAI_StatusItem*)(payload_base + status_block->data_offset);
    for (uint32_t i = 0; i < status_block->count; ++i)
    {
        const RMAI_StatusItem& status = status_list[i];
        float parsed = 0.f;
        if (!parse_status_speed_kmh(status.text, &parsed))
        {
            continue;
        }

        if (RMAI_STATUS_ADAS_CAR_SPEED == status.status_type && !*car_speed_found)
        {
            *car_speed_kmh = parsed;
            *car_speed_found = true;
        }
        else if (RMAI_STATUS_ADAS_CAR_RELATIVE_SPEED == status.status_type &&
                 !*relative_speed_found)
        {
            *relative_speed_kmh = parsed;
            *relative_speed_found = true;
        }
    }
}

} // namespace

bool compute_front_vehicle_speed_kmh(
    const std::vector<StructOverlayGroupItem>& overlays,
    float* out_front_speed_kmh)
{
    if (NULL == out_front_speed_kmh)
    {
        return false;
    }

    bool has_fcw = false;
    bool has_ldw = false;
    bool car_speed_found = false;
    bool relative_speed_found = false;
    float car_speed_kmh = 0.f;
    float relative_speed_kmh = 0.f;

    for (size_t i = 0; i < overlays.size(); ++i)
    {
        const StructOverlayGroupItem& item = overlays[i];
        if (RMAI_ALG_FCW_HMW == item.group.alg_type)
        {
            has_fcw = true;
        }
        else if (RMAI_ALG_LDW == item.group.alg_type)
        {
            has_ldw = true;
        }

        collect_status_speeds_from_overlay(
            item, &car_speed_found, &car_speed_kmh,
            &relative_speed_found, &relative_speed_kmh);
    }

    if (!has_fcw || !has_ldw || !car_speed_found || !relative_speed_found)
    {
        return false;
    }

    *out_front_speed_kmh = car_speed_kmh + relative_speed_kmh;
    return true;
}
