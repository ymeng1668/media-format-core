#include "video_decoder.h"
#include <stdio.h>
#include <string.h>

CVideoDecoder::CVideoDecoder()
{
    m_codec = NULL;
    m_codecCtx = NULL;
    m_frame = NULL;
    m_packet = NULL;
    m_width = 0;
    m_height = 0;
    m_codecId = AV_CODEC_ID_H264;
}

CVideoDecoder::~CVideoDecoder()
{
    UnInitDecoder();
}

int CVideoDecoder::InitDecoder(AVCodecID codecId, int width, int height)
{
    if (NULL != m_frame)
    {
        return 0;  // 已经初始化
    }

    m_codecId = codecId;
    m_width = width;
    m_height = height;

    m_packet = av_packet_alloc();
    if (NULL == m_packet)
    {
        fprintf(stderr, "Could not allocate packet\n");
        return -1;
    }

    // 查找解码器
    if (codecId == AV_CODEC_ID_H264)
    {
        m_codec = avcodec_find_decoder(AV_CODEC_ID_H264);
    }
    else if (codecId == AV_CODEC_ID_H265)
    {
        m_codec = avcodec_find_decoder(AV_CODEC_ID_H265);
    }
    else
    {
        fprintf(stderr, "Unsupported codec\n");
        return -1;
    }

    if (NULL == m_codec)
    {
        fprintf(stderr, "Codec not found\n");
        return -1;
    }

    m_codecCtx = avcodec_alloc_context3(m_codec);
    if (NULL == m_codecCtx)
    {
        fprintf(stderr, "Could not allocate video codec context\n");
        return -1;
    }

    // 注意：不要在打开解码器前设置宽高！
    // H.264/H.265 解码器会从 SPS/PPS 中自动提取这些参数
    // 提前设置会导致解码错误

    // 打开解码器
    if (avcodec_open2(m_codecCtx, m_codec, NULL) < 0)
    {
        fprintf(stderr, "Could not open codec\n");
        avcodec_free_context(&m_codecCtx);
        m_codecCtx = NULL;
        return -1;
    }

    m_frame = av_frame_alloc();
    if (NULL == m_frame)
    {
        fprintf(stderr, "Could not allocate video frame\n");
        avcodec_free_context(&m_codecCtx);
        m_codecCtx = NULL;
        return -1;
    }

    return 0;
}

void CVideoDecoder::UnInitDecoder()
{
    if (NULL != m_codecCtx)
    {
        avcodec_free_context(&m_codecCtx);
        m_codecCtx = NULL;
    }
    if (NULL != m_frame)
    {
        av_frame_free(&m_frame);
        m_frame = NULL;
    }
    if (NULL != m_packet)
    {
        av_packet_free(&m_packet);
        m_packet = NULL;
    }
    m_codec = NULL;
}

int CVideoDecoder::decode(AVCodecContext *decCtx, AVFrame *frame, AVPacket *pkt)
{
    int ret = avcodec_send_packet(decCtx, pkt);
    if (ret < 0)
    {
        if (ret != AVERROR(EAGAIN) && ret != AVERROR_EOF)
        {
            fprintf(stderr, "Error sending a packet for decoding\n");
        }
        return 0;
    }

    while (ret >= 0)
    {
        ret = avcodec_receive_frame(decCtx, frame);
        if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF)
        {
            return 0;
        }
        else if (ret < 0)
        {
            fprintf(stderr, "Error during decoding\n");
            return 0;
        }

        // 更新宽高信息
        if (m_width == 0 || m_height == 0)
        {
            m_width = frame->width;
            m_height = frame->height;
        }

        return 1;  // 解码成功
    }

    return 0;
}

int CVideoDecoder::DecodeFrame(const uint8_t *frameData, int frameLen, AVFrame **avFrame)
{
    if (NULL == m_frame || NULL == frameData || frameLen <= 0)
    {
        return -1;
    }

    m_packet->data = const_cast<uint8_t*>(frameData);
    m_packet->size = frameLen;

    int ret = decode(m_codecCtx, m_frame, m_packet);

    if (ret == 1 && NULL != avFrame)
    {
        *avFrame = m_frame;
    }

    return ret;
}

#if defined(USE_OPENCV)
int CVideoDecoder::AVFrameToMat(AVFrame *avFrame, cv::Mat &mat)
{
    if (NULL == avFrame)
    {
        return -1;
    }

    int width = avFrame->width;
    int height = avFrame->height;

    // 创建目标BGR图像
    mat = cv::Mat(height, width, CV_8UC3);

    // 使用 sws_scale 进行颜色空间转换（YUV420P -> BGR24）
    struct SwsContext *swsCtx = sws_getContext(
        width, height, AV_PIX_FMT_YUV420P,
        width, height, AV_PIX_FMT_BGR24,
        SWS_BILINEAR, NULL, NULL, NULL);

    if (NULL == swsCtx)
    {
        fprintf(stderr, "Failed to create sws context\n");
        return -1;
    }

    // 转换
    uint8_t *dstData[1] = { mat.data };
    int dstLinesize[1] = { static_cast<int>(mat.step[0]) };

    sws_scale(swsCtx, avFrame->data, avFrame->linesize, 0, height,
              dstData, dstLinesize);

    sws_freeContext(swsCtx);

    return 0;
}
#endif

